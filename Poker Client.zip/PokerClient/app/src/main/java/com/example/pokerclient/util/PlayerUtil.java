package com.example.pokerclient.util;


import com.example.pokerclient.lib.hand.HandRank;
import com.example.pokerclient.lib.hand.HandRankEvaluator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayerUtil {

    private static HandRankEvaluator evaluator = HandRankEvaluator.getInstance();


    public static int getNextPlayerInGameOrder(List<Integer> players, int startPlayer) {
        for (int i = 0; i < players.size(); i++) {
            if ((int) players.get(i) == startPlayer) {
                return (int) ((i == players.size() - 1) ? players.get(0) : players.get(i + 1));
            }
        }
        return 0;
    }

    public static int getNextPlayerInGameOrderPH(List<Integer> playerHands, int startPlayer) {
        return getNextPlayerInGameOrder(playerHands, startPlayer);
    }


    public static int getNextPlayerToAct(Map<String, Object> hand, List<Map<String, Object>> hand_players, List<Map<String, Object>> players, int startPlayer) {
        List<Integer> players_id = new ArrayList<>();
        for (int j = 0; j < players.size(); j++) {
            players_id.add(Integer.parseInt(players.get(j).get("player_id").toString()));
        }
        int next = startPlayer;

        //Skip all in players and sitting out players
        boolean lookingForNextPlayer = true;
        List<Integer> playersToRemove = new ArrayList<Integer>();
        while (lookingForNextPlayer) {
            next = PlayerUtil.getNextPlayerInGameOrderPH(players_id, next);
            //Escape condition
            if (next == startPlayer) {
                break;
            }
            int i;
            for (i = 0; i < players.size(); i++) {
                if (Integer.parseInt(players.get(i).get("player_id").toString()) == next) {
                    break;
                }
            }
            Map<String, Object> player = players.get(i);
            //If the player is sitting out, it will not be next to act
            if (Boolean.parseBoolean(player.get("sitting_out").toString())) {

                //Player is sitting out and needs to call, automatic fold
                for (i = 0; i < hand_players.size(); i++) {
                    if (Integer.parseInt(hand_players.get(i).get("player_id").toString()) == next) {
                        break;
                    }
                }
                Map<String, Object> player_hand = hand_players.get(i);

                if (Integer.parseInt(hand.get("total_bet_amount").toString()) > Integer.parseInt(player_hand.get("round_bet_amount").toString())) {
                    playersToRemove.add(next);
                }
            }
            //If the player is not sitting out and still has chips, then this player is next to act
            else if (Integer.parseInt(player.get("chips").toString()) > 0) {
                lookingForNextPlayer = false;
            }
        }
        //Remove sitting out players
        for (int p : playersToRemove) {
            removePlayerFromHand(p, hand);
        }

        return next;
    }


    public static int removePlayerFromHand(int player, Map<String, Object> hand) {
        List<Integer> players = (List<Integer>) hand.get("players");
        for (int i = 0; i < players.size(); i++) {
            if (Integer.parseInt(players.get(i) + "") == player) {
                return i;
            }
        }
        return -1;
    }

    public static List<Integer> getWinnersOfHand(Map<String, Object> board, List<Map<String, Object>> players_hand) {
        List<Integer> winners = new ArrayList<Integer>();
        HandRank highestRank = null;
        for (Map<String, Object> ph : players_hand) {
            HandRank rank = evaluator.evaluate(board, ph);
            if (highestRank == null) {
                highestRank = rank;
                winners.clear();
                winners.add(Integer.parseInt(ph.get("player_id").toString()));
                continue;
            }

            int comp = rank.compareTo(highestRank);
            if (comp > 0) {
                //New best
                highestRank = rank;
                winners.clear();
                winners.add(Integer.parseInt(ph.get("player_id").toString()));
            } else if (comp == 0) {
                winners.add(Integer.parseInt(ph.get("player_id").toString()));
            }
        }

        return winners;
    }

    public static Map<Integer, Integer> getAmountWonInHandForAllPlayers(Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand) {
        if (board.get("river") == null) {
            return null;
        }

        Map<Integer, Integer> winnersMap = new HashMap<Integer, Integer>();

        resolveSidePot(winnersMap, hand, board, 0, players_hand);
        resolveDeadMoney(winnersMap, hand);

        return winnersMap;
    }


    private static void applyWinningAndChips(Map<Integer, Integer> winnersMap, Map<String, Object> board,
                                             int minPlayerBetAmount, List<Map<String, Object>> playersInvolved) {
        List<Integer> winners = PlayerUtil.getWinnersOfHand(board, playersInvolved);
        int potSplit = (minPlayerBetAmount * playersInvolved.size()) / winners.size();
        //Odd chips go to first player in game order
        int remaining = (minPlayerBetAmount * playersInvolved.size()) % winners.size();
        for (int player : winners) {
            Integer bigIValue = winnersMap.get(player);
            int i = (bigIValue == null) ? 0 : bigIValue;
            winnersMap.put(player, potSplit + remaining + i);
            remaining = 0;
        }
    }

    private static void resolveSidePot(Map<Integer, Integer> winnersMap, Map<String, Object> hand, Map<String, Object> board,
                                       int allInBetRunningTotal, List<Map<String, Object>> players_hand) {
        Map<String, Object> allInPlayer = null;
        Map<String, Object> potentialAllInPlayer = null;
        int minimumBetAmountPerPlayer = 0;
        for (Map<String, Object> ph : players_hand) {
            int betAmount = Integer.parseInt(ph.get("bet_amount").toString());
            if (minimumBetAmountPerPlayer == 0) {
                minimumBetAmountPerPlayer = betAmount;
                potentialAllInPlayer = ph;
            } else if (minimumBetAmountPerPlayer > betAmount) {
                minimumBetAmountPerPlayer = betAmount;
                allInPlayer = ph;
                potentialAllInPlayer = allInPlayer;
            } else if (minimumBetAmountPerPlayer < betAmount) {
                allInPlayer = potentialAllInPlayer;
            }
        }
        minimumBetAmountPerPlayer = minimumBetAmountPerPlayer - allInBetRunningTotal;
        allInBetRunningTotal += minimumBetAmountPerPlayer;

        if (allInPlayer == null || players_hand.size() == 2) {
            applyWinningAndChips(winnersMap, board, minimumBetAmountPerPlayer, players_hand);
            return;
        }

        applyWinningAndChips(winnersMap, hand, minimumBetAmountPerPlayer, players_hand);
        players_hand.remove(allInPlayer);
        resolveSidePot(winnersMap, hand, board, allInBetRunningTotal, players_hand);

    }

    private static void resolveDeadMoney(Map<Integer, Integer> winnersMap, Map<String, Object> hand) {
        int payout = 0;
        for (int player : winnersMap.keySet()) {
            payout += winnersMap.get(player);
        }
        int deadMoney = Integer.parseInt(hand.get("pot").toString()) - payout;
        for (int player : winnersMap.keySet()) {
            winnersMap.put(player, winnersMap.get(player) + deadMoney / winnersMap.size());
        }
        int remainder = deadMoney % winnersMap.size();
        int oddChipWinner = winnersMap.keySet().iterator().next();
        winnersMap.put(oddChipWinner, winnersMap.get(oddChipWinner) + remainder);
    }
}
