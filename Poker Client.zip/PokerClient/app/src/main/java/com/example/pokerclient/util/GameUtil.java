/*
The MIT License (MIT)

Copyright (c) 2013 Jacob Kanipe-Illig

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
package com.example.pokerclient.util;

import androidx.annotation.NonNull;

import com.example.pokerclient.lib.GameStatus;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class GameUtil {

    public static GameStatus getGameStatus(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board) {
        if (!Boolean.parseBoolean(game.get("is_started").toString())) {
            return GameStatus.NOT_STARTED;
        }

        if (hand == null) {
            return GameStatus.SEATING;
        }

        if (Integer.parseInt(hand.get("current_to_act").toString()) == 0) {
            return GameStatus.END_HAND;
        }

        if (board.get("river") != null) {
            return GameStatus.RIVER;
        }

        if (board.get("turn") != null) {
            return GameStatus.TURN;
        }

        if (board.get("flop1") != null) {
            return GameStatus.FLOP;
        }

        return GameStatus.PREFLOP;
    }
}
