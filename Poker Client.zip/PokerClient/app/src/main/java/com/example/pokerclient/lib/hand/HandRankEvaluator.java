package com.example.pokerclient.lib.hand;

import com.example.pokerclient.lib.card.Card;
import com.example.pokerclient.lib.card.CardIterator;

import java.util.Iterator;
import java.util.Map;

public class HandRankEvaluator {

    private static HandRankEvaluator instance;


    public static HandRankEvaluator getInstance() {
        if (instance == null) {
            instance = new HandRankEvaluator();
        }
        return instance;
    }

    public HandRank evaluate(Map<String, Object> board, Map<String, Object> player_hand) {
        Board board1 = new Board(Card.getCard(board.get("flop1").toString()),
                Card.getCard(board.get("flop2").toString()),
                Card.getCard(board.get("flop3").toString()),
                Card.getCard(board.get("turn").toString()),
                Card.getCard(board.get("river").toString()));
        Hand hand = new Hand(Card.getCard(player_hand.get("card1").toString()),
                Card.getCard(player_hand.get("card2").toString()));
        Iterator<Card> cardIterator = new CardIterator(board1, hand);
        int p = 0;
        while (cardIterator.hasNext()) {
            Card card = cardIterator.next();
            p = card.getEvaluation();
        }
        return new HandRank(p);
    }
}
