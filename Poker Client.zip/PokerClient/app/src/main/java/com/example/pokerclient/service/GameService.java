package com.example.pokerclient.service;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pokerclient.activity.PokerActivity;
import com.example.pokerclient.lib.GameStatus;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.manager.PreferencesManager;
import com.example.pokerclient.util.GameUtil;
import com.example.pokerclient.util.PlayerUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameService {

    public static boolean finish = true;

    public PokerActivity pokerActivity;
    public PokerHandService pokerHandService;
    private ListenerRegistration listenerGame;
    private ListenerRegistration listenerGameNotStarted;
    private ListenerRegistration listenerPlayerHand;
    private ListenerRegistration listenerPlayer;

    public GameService(PokerActivity pokerActivity) {
        this.pokerActivity = pokerActivity;
        this.pokerHandService = new PokerHandService(this);
    }

    public void gameController() {
        int gameId = PreferencesManager.getGameId(pokerActivity);
        int playerId = PreferencesManager.getPlayerId(pokerActivity);
        listenerGame = FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .whereEqualTo("btn_player_id", playerId)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            return;
                        }
                        if (!finish) {
                            return;
                        }
                        finish = false;
                        for (QueryDocumentSnapshot docGame : value) {
                            Map<String, Object> gameStructure = (Map<String, Object>) docGame.get("game_structure");
                            int remaining = Integer.parseInt(docGame.get("players_remaining").toString());
                            int max_players = Integer.parseInt(gameStructure.get("max_players").toString());

                            if (Boolean.parseBoolean(docGame.get("is_started").toString())) {

                            } else if (remaining == max_players) {
                                FirebaseStoreManager.getLastHandID().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {
                                            int hand_id = 1;
                                            if (task.getResult().size() > 0) {
                                                for (QueryDocumentSnapshot document : task.getResult()) {
                                                    hand_id = Integer.parseInt(document.get("hand_id").toString()) + 1;
                                                }
                                            }
                                            final Map<String, Object> hand = new HashMap<>();
                                            hand.put("hand_id", hand_id);
                                            hand.put("game_id", gameId);
                                            FirebaseStoreManager.db.collection("players")
                                                    .whereEqualTo("game_id", gameId)
                                                    .get()
                                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                            if (task.isSuccessful()) {
                                                                List<Map<String, Object>> players = new ArrayList<>();
                                                                for (DocumentSnapshot docPlayers : task.getResult()) {
                                                                    players.add(docPlayers.getData());
                                                                }
                                                                pokerHandService.startNewHand(docGame.getData(), hand, players);


                                                            }
                                                        }
                                                    });


                                        }
                                    }
                                });
                            } else {
                                finish = true;
                            }
                        }

                    }
                });
        listenerGameNotStarted = FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .whereEqualTo("is_started", false)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            return;
                        }
                        if (value == null) {
                            return;
                        }
                        if (value.getDocuments().size() == 0) {
                            return;
                        }
                        DocumentSnapshot gameDoc = value.getDocuments().get(0);
                        Map<String, Object> game = gameDoc.getData();
                        Map<String, Object> gameStructure = (Map<String, Object>) game.get("game_structure");
                        int remaining = Integer.parseInt(game.get("players_remaining").toString());
                        int max_players = Integer.parseInt(gameStructure.get("max_players").toString());
                        if (remaining == max_players) {
                            if (Integer.parseInt(game.get("btn_player_id").toString()) == playerId) {
                                game.put("is_started", true);
                                FirebaseStoreManager.updateGame(gameDoc.getId(), game);
                            }
                            pokerActivity.playerStatusTask();
                        }
                    }
                });
    }

    public void handController() {
        int playerId = PreferencesManager.getPlayerId(pokerActivity);
        listenerPlayerHand = FirebaseStoreManager.db.collection("player_hand")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            return;
                        }
                        if (value == null) {
                            return;
                        }
                        if (value.getDocuments().size() == 0) {
                            return;
                        }
                        pokerActivity.playerStatusTask();
                    }
                });
        listenerPlayer = FirebaseStoreManager.db.collection("players")
                .whereEqualTo("player_id", playerId)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            return;
                        }
                        if (value == null) {
                            return;
                        }
                        if (value.getDocuments().size() == 0) {
                            return;
                        }
                        DocumentSnapshot playerDoc = value.getDocuments().get(0);
                        if (pokerActivity.lastPlayerStatus == null) {
                            return;
                        }
                        if (pokerActivity.lastPlayerStatus.getChips() < Integer.parseInt(playerDoc.get("chips").toString())) {
                            pokerActivity.blackChipAnimWon();
                        }
                    }
                });
    }

    public void boardCards(int next_to_act) {
        int gameId = PreferencesManager.getGameId(pokerActivity);
        FirebaseStoreManager.db.collection("hand")
                .whereEqualTo("game_id", gameId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().getDocuments().size() == 0) {
                                return;
                            }
                            DocumentSnapshot handDoc = task.getResult().getDocuments().get(0);
                            Map<String, Object> hand = handDoc.getData();

                            FirebaseStoreManager.db.collection("game")
                                    .whereEqualTo("is_started", true)
                                    .whereEqualTo("game_id", gameId)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                if (task.getResult().size() == 0) {
                                                    return;
                                                }
                                                DocumentSnapshot gameDoc = task.getResult().getDocuments().get(0);
                                                Map<String, Object> game = gameDoc.getData();
                                                FirebaseStoreManager.db.collection("board")
                                                        .document(game.get("name").toString())
                                                        .get()
                                                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                                if (task.isSuccessful()) {
                                                                    DocumentSnapshot boardDoc = task.getResult();
                                                                    Map<String, Object> board = boardDoc.getData();
                                                                    FirebaseStoreManager.db.collection("players")
                                                                            .whereEqualTo("game_id", gameId)
                                                                            .get()
                                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                    if (task.isSuccessful()) {
                                                                                        List<Map<String, Object>> players = new ArrayList<>();
                                                                                        List<Integer> players_id = new ArrayList<>();
                                                                                        for (DocumentSnapshot playerDoc : task.getResult()) {
                                                                                            players.add(playerDoc.getData());
                                                                                            players_id.add(Integer.parseInt(playerDoc.get("player_id").toString()));
                                                                                        }

                                                                                        FirebaseStoreManager.db.collection("player_hand")
                                                                                                .whereEqualTo("hand_id", game.get("current_hand"))
                                                                                                .get()
                                                                                                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                                    @Override
                                                                                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                                        if (task.isSuccessful()) {
                                                                                                            List<Map<String, Object>> players_hand = new ArrayList<>();
                                                                                                            for (DocumentSnapshot playerHandDoc : task.getResult()) {
                                                                                                                players_hand.add(playerHandDoc.getData());
                                                                                                            }

                                                                                                            List<Integer> players_in_hand = (List<Integer>) handDoc.get("players");
                                                                                                            if (players_in_hand.size() == 1) {
                                                                                                                pokerHandService.endHand(game, hand, board, players_hand, players, gameDoc.getId());
                                                                                                                return;
                                                                                                            }
                                                                                                            if (next_to_act != Integer.parseInt(game.get("btn_player_id").toString())) {
                                                                                                                return;
                                                                                                            }

                                                                                                            GameStatus gameStatus = GameUtil.getGameStatus(game, hand, board);
                                                                                                            if (gameStatus == GameStatus.PREFLOP) {
                                                                                                                pokerHandService.flop(game, hand, board, players_hand, players, gameDoc.getId());
                                                                                                            } else if (gameStatus == GameStatus.FLOP) {
                                                                                                                pokerHandService.turn(game, hand, board, players_hand, players, gameDoc.getId());
                                                                                                            } else if (gameStatus == GameStatus.TURN) {
                                                                                                                pokerHandService.river(game, hand, board, players_hand, players, gameDoc.getId());
                                                                                                            }

                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                    }
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        });


                                            }
                                        }
                                    });

                        }
                    }
                });
    }

    public void destroy() {
        listenerGame.remove();
        listenerGameNotStarted.remove();
        listenerPlayerHand.remove();
        listenerPlayer.remove();
    }

    public static int getPlayerInSB
            (Map<String, Object> hand, Map<String, Object> game) {
        int button = Integer.parseInt(game.get("btn_player_id").toString());
        List<Integer> players = (List<Integer>) hand.get("players");
        if (players.size() == 2) {
            return button;
        }
        return PlayerUtil.getNextPlayerInGameOrderPH(players, button);
    }

    public static int getPlayerInBB
            (Map<String, Object> hand, Map<String, Object> game) {
        int button = Integer.parseInt(game.get("btn_player_id").toString());
        List<Integer> players = new ArrayList<>();
        for (Object p : (List<Integer>) hand.get("players")) {
            players.add(Integer.parseInt(p.toString()));
        }
        int leftOfButton = PlayerUtil.getNextPlayerInGameOrder(players, button);
        if (players.size() == 2) {
            return leftOfButton;
        }
        return PlayerUtil.getNextPlayerInGameOrderPH(players, leftOfButton);
    }

    public static Task<QuerySnapshot> addNewPlayerToGame(int gameId) {
        return FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId).get();
    }
}
