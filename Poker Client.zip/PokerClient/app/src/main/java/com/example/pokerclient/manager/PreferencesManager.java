package com.example.pokerclient.manager;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferencesManager {
    private static final String VIBRATE_KEY = "vibrate_allowed";
    private static final String USERNAME = "username";
    private static final String GAME_ID_KEY = "game_id";
    private static final String GAME_NAME_KEY = "game_name";
    private static final String PLAYER_ID = "player_id";
    public static boolean isVibrateEnabled(Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        return pref.getBoolean(VIBRATE_KEY, true);
    }

    public static void setVibrateEnabled(boolean vibrateEnabled, Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean(VIBRATE_KEY, vibrateEnabled);
        editor.commit();
    }

    public static void setUsername(String username, Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(USERNAME, username);
        editor.commit();
    }

    public static String getUsername(Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        return pref.getString(USERNAME, "");
    }

    public static int getGameId(Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        return pref.getInt(GAME_ID_KEY, 0);
    }

    public static void setGameId(int gameId, Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt(GAME_ID_KEY, gameId);
        editor.commit();
    }

    public static String getGameName(Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        return pref.getString(GAME_NAME_KEY, "");
    }

    public static void setGameName(String gameName, Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(GAME_NAME_KEY, gameName);
        editor.commit();
    }

    public static void setPlayerId(int playerId, Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = pref.edit();
        editor.putInt(PLAYER_ID, playerId);
        editor.commit();
    }

    public static int getPlayerId(Context ctx){
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(ctx);
        return pref.getInt(PLAYER_ID, 0);
    }
}
