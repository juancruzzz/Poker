package com.example.pokerclient.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pokerclient.R;
import com.example.pokerclient.lib.card.Card;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.manager.PreferencesManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nullable;


public class SignInActivity extends AppCompatActivity {
    private static final int RC_SIGN_IN = 9001;
    private FirebaseAuth mAuth;

    private EditText fieldUsername;
    private Button btnAnonymouse;
    private String TAG = "LOGIN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        fieldUsername = findViewById(R.id.field_username);
        btnAnonymouse = findViewById(R.id.button_anonymous_sign_in);

        mAuth = FirebaseAuth.getInstance();
    }

    private void updateUI(FirebaseUser user) {
        String username = PreferencesManager.getUsername(getBaseContext());
        if (user != null) {
            Intent intent = new Intent(this, GameSelectionActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        } else {
            if (username == "") {
                fieldUsername.setText("PLAYER" + (Math.round(Math.random() * 1000000)));
            } else {
                fieldUsername.setText(username);
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    public void onClick(View v) {
        if (v == btnAnonymouse) {
            String username = fieldUsername.getText().toString();
            if (username.isEmpty()) {
                fieldUsername.setError("Campo obligatorio");
                return;
            }
            FirebaseStoreManager.isExistPlayerName(username).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                @Override
                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                        if (task.getResult().size() == 0) {
                            FirebaseStoreManager.getLastPlayerID().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    int player_id = 1;
                                    if (task.getResult().size() > 0) {
                                        for (QueryDocumentSnapshot document : task.getResult()) {
                                            player_id = Integer.parseInt(document.get("player_id").toString()) + 1;
                                        }
                                    }
                                    Map<String, Object> player = new HashMap<>();
                                    player.put("chips", 0);
                                    player.put("finish_position", 0);
                                    player.put("game_id", 0);
                                    player.put("game_position", 0);
                                    player.put("name", username);
                                    player.put("player_id", player_id);
                                    player.put("sitting_out", false);
                                    FirebaseStoreManager.savePlayer(player);
                                }
                            });
                        }
                    }
                }
            });

            mAuth.signInAnonymously()
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d(TAG, "signInAnonymously:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                PreferencesManager.setUsername(username, getBaseContext());
                                updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w(TAG, "signInAnonymously:failure", task.getException());
                                updateUI(null);
                            }
                        }
                    });
        }
    }

}