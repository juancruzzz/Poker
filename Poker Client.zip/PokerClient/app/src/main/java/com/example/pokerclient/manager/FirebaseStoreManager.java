package com.example.pokerclient.manager;


import androidx.annotation.NonNull;

import com.example.pokerclient.lib.GameStructure;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;


public class FirebaseStoreManager {
    public static final FirebaseFirestore db = FirebaseFirestore.getInstance();
    public static final int NONE = 0;
    public static final int GET_GAME_STRUCTURE = 1;
    public static final int CREATE_GAME = 2;
    public static final int GAME_NAME_EXIST = 3;
    public static final int GET_GAME_STRUCTURE_BY_DESC = 4;
    public static final int SAVE_PLAYER = 5;
    public static final int SAVE_GAME = 6;
    public static final int GET_PLAYER_BY_ID = 7;
    public static final int GET_GAME_BY_ID = 8;
    public static int QUERY = 0;


    public static Task<QuerySnapshot> getGameStructure() {
        QUERY = GET_GAME_STRUCTURE;
        return db.collection("game_structure").get();
    }

    public static Task<QuerySnapshot> getGameStructureByDescription(String description) {
        QUERY = GET_GAME_STRUCTURE_BY_DESC;
        return db.collection("game_structure").whereEqualTo("description", description).get();
    }

    public static void createGame(GameStructure game) {
        QUERY = CREATE_GAME;
        getLastGameID().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    int game_id = 1;
                    if (task.getResult().size() > 0) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            game_id = Integer.parseInt(document.get("game_id").toString()) + 1;
                        }
                    }
                    Map<String, Object> data1 = new HashMap<>();
                    data1.put("game_id", game_id);
                    data1.put("name", game.getName());
                    data1.put("players_remaining", 0);
                    data1.put("is_started", false);
                    data1.put("current_hand", 0);
                    data1.put("game_structure", game.toJSON());
                    data1.put("btn_player_id", 0);
                    data1.put("max_time_to_init", (System.currentTimeMillis() / 1000L) + 900);
                    db.collection("game").document(game.getName()).set(data1);
                }
            }
        });
    }

    public static void removeGame(String name) {
        db.collection("game").document(name).delete();
    }

    public static Task<QuerySnapshot> isExistGameName(String name) {
        QUERY = GAME_NAME_EXIST;
        return db.collection("game").whereEqualTo("name", name).get();
    }

    public static Task<QuerySnapshot> getLastGameID() {
        return db.collection("game").orderBy("game_id", Query.Direction.DESCENDING).limit(1).get();
    }

    public static Task<QuerySnapshot> isExistPlayerName(String name) {
        QUERY = GAME_NAME_EXIST;
        return db.collection("players").whereEqualTo("name", name).get();
    }

    public static void savePlayer(Map<String, ?> player) {
        QUERY = SAVE_PLAYER;
        db.collection("players").document(player.get("name").toString()).set(player);
    }

    public static void saveGame(Map<String, ?> game) {
        QUERY = SAVE_PLAYER;
        db.collection("game").document(game.get("name").toString()).set(game);
    }

    public static Task<DocumentSnapshot> getPlayer(String player) {
        QUERY = GET_PLAYER_BY_ID;
        return db.collection("players").document(player).get();
    }

    public static Task<QuerySnapshot> getGameById(int gameId) {
        QUERY = GET_GAME_BY_ID;
        return db.collection("game").whereEqualTo("game_id", gameId).get();
    }

    public static Task<QuerySnapshot> getLastPlayerID() {
        return db.collection("players").orderBy("player_id", Query.Direction.DESCENDING).limit(1).get();
    }

    public static Task<QuerySnapshot> getLastHandID() {
        return db.collection("hand").orderBy("hand_id", Query.Direction.DESCENDING).limit(1).get();
    }

    public static Task<QuerySnapshot> getLastPlayerHandID() {
        return db.collection("player_hand").orderBy("player_hand_id", Query.Direction.DESCENDING).limit(1).get();
    }

    public static Task<Void> updatePlayerHandRoundBetAmount(String playerName, int round_bet_amount) {
        return db.collection("player_hand").document(playerName).update("round_bet_amount", round_bet_amount);
    }

    public static Task<Void> updateGame(String gameDoc, Map<String, Object> updateGame) {
        return FirebaseStoreManager.db.collection("game")
                .document(gameDoc)
                .update(updateGame);
    }

    public static Task<Void> setHand(String handDoc, Map<String, Object> setHand) {
        return FirebaseStoreManager.db.collection("hand")
                .document(handDoc)
                .set(setHand);
    }

    public static Task<Void> updateHand(String handDoc, Map<String, Object> updateHand) {
        return FirebaseStoreManager.db.collection("hand")
                .document(handDoc)
                .update(updateHand);
    }

    public static Task<Void> setHandPlayer(String playerName, Map<String, Object> setHandPlayer) {
        return FirebaseStoreManager.db.collection("player_hand")
                .document(playerName)
                .set(setHandPlayer);
    }

    public static Task<Void> updateHandPlayer(String playerName, Map<String, Object> updateHandPlayer) {
        return FirebaseStoreManager.db.collection("player_hand")
                .document(playerName)
                .update(updateHandPlayer);
    }
}
