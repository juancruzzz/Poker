package com.example.pokerclient.service;

import androidx.annotation.NonNull;

import com.example.pokerclient.activity.PokerActivity;
import com.example.pokerclient.lib.BlindLevel;
import com.example.pokerclient.lib.GameStatus;
import com.example.pokerclient.lib.card.Card;
import com.example.pokerclient.lib.player.PlayerStatus;
import com.example.pokerclient.lib.player.PlayerStatusType;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.util.GameUtil;
import com.example.pokerclient.util.PlayerUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayerActionService {
    private PokerActivity pokerActivity;

    public PlayerActionService(PokerActivity pokerActivity) {
        this.pokerActivity = pokerActivity;
    }

    public boolean fold(List<Map<String, Object>> players, List<Map<String, Object>> hand_players, Map<String, Object> hand, int playerId, String gameName) {
        int i;
        for (i = 0; i < hand_players.size(); i++) {
            if (Integer.parseInt(hand_players.get(i).get("player_id").toString()) == playerId) {
                break;
            }
        }
         if (playerId != Integer.parseInt(hand.get("current_to_act").toString())) {
            return false;
        }
        int next = PlayerUtil.getNextPlayerToAct(hand, hand_players, players, playerId);
        int remove_player = PlayerUtil.removePlayerFromHand(playerId, hand);
        if (remove_player == -1) {
            return false;
        }

        List<Integer> player_list = (List<Integer>) hand.get("players");
        player_list.remove(remove_player);
        hand.put("players", player_list);
        hand.put("current_to_act", next);
        FirebaseStoreManager.updateHand(gameName, hand)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            pokerActivity.gameService.boardCards(next);
                        }
                    }
                });
        return true;
    }

    public boolean check(List<Map<String, Object>> players, List<Map<String, Object>> hand_players, Map<String, Object> hand, int playerId, PlayerStatus status, String gameName) {
        if (playerId != Integer.parseInt(hand.get("current_to_act").toString())) {
            return false;
        }

        if (status.getStatus() != PlayerStatusType.ACTION_TO_CHECK) {
            return false;
        }

        int next = PlayerUtil.getNextPlayerToAct(hand, hand_players, players, playerId);
        hand.put("current_to_act", next);
        FirebaseStoreManager.updateHand(gameName, hand).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    pokerActivity.gameService.boardCards(next);
                }
            }
        });
        return true;
    }

    public boolean bet(List<Map<String, Object>> players, List<Map<String, Object>> hand_players, Map<String, Object> hand, int playerId, int betAmount, String gameName) {
        int i;
        for (i = 0; i < hand_players.size(); i++) {
            if (Integer.parseInt(hand_players.get(i).get("player_id").toString()) == playerId) {
                break;
            }
        }
        Map<String, Object> player = players.get(i);
        Map<String, Object> hand_player = hand_players.get(i);
        if (player.get("player_id") != hand.get("current_to_act")) {
            return false;
        }

        if (betAmount < Integer.parseInt(hand.get("last_bet_amount").toString()) ||
                betAmount < BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind()) {
            return false;
        }


        int toCall = Integer.parseInt(hand.get("total_bet_amount").toString()) -
                Integer.parseInt(hand_player.get("round_bet_amount").toString());
        int total = betAmount + toCall;
        int chips = Integer.parseInt(player.get("chips").toString());
        if (total > chips) {
            total = chips;
            betAmount = total - toCall;
        }

        hand_player.put("round_bet_amount", Integer.parseInt(hand_player.get("round_bet_amount").toString()) + total);
        hand_player.put("bet_amount", Integer.parseInt(hand_player.get("bet_amount").toString()) + total);

        FirebaseStoreManager.db.collection("player_hand")
                .document(player.get("name").toString())
                .update(hand_player);
        FirebaseStoreManager.db.collection("players")
                .document(player.get("name").toString())
                .update("chips", Integer.parseInt(player.get("chips").toString()) - total);

        hand.put("pot", Integer.parseInt(hand.get("pot").toString()) + total);
        hand.put("last_bet_amount", betAmount);
        hand.put("total_bet_amount", Integer.parseInt(hand.get("total_bet_amount").toString()) + total);
        int next = PlayerUtil.getNextPlayerToAct(hand, hand_players, players, playerId);
        hand.put("current_to_act", next);
        FirebaseStoreManager.updateHand(gameName, hand)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            pokerActivity.gameService.boardCards(next);
                        }
                    }
                });
        return true;
    }


    public boolean call(List<Map<String, Object>> players, List<Map<String, Object>> hand_players, Map<String, Object> hand, int playerId, String gameName) {
       int i;
        for (i = 0; i < hand_players.size(); i++) {
            if (Integer.parseInt(hand_players.get(i).get("player_id").toString()) == playerId) {
                break;
            }
        }
        Map<String, Object> player = players.get(i);
        Map<String, Object> hand_player = hand_players.get(i);
        if (player.get("player_id") != hand.get("current_to_act")) {
            return false;
        }

        int toCall = Integer.parseInt(hand.get("total_bet_amount").toString()) -
                Integer.parseInt(hand_player.get("round_bet_amount").toString());
        toCall = Math.min(toCall, Integer.parseInt(player.get("chips").toString()));
        if (toCall <= 0) {
            return false;
        }

        hand_player.put("round_bet_amount", Integer.parseInt(hand_player.get("round_bet_amount").toString()) + toCall);
        hand_player.put("bet_amount", Integer.parseInt(hand_player.get("bet_amount").toString()) + toCall);

        FirebaseStoreManager.db.collection("player_hand")
                .document(player.get("name").toString())
                .update(hand_player);

        FirebaseStoreManager.db.collection("players")
                .document(player.get("name").toString())
                .update("chips", Integer.parseInt(player.get("chips").toString()) - toCall);


        hand.put("pot", Integer.parseInt(hand.get("pot").toString()) + toCall);
        int next = PlayerUtil.getNextPlayerToAct(hand, hand_players, players, playerId);
        hand.put("current_to_act", next);
        FirebaseStoreManager.updateHand(gameName, hand)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            pokerActivity.gameService.boardCards(next);
                        }
                    }
                });
        return true;
    }

    public boolean sitIn(String playerName) {
        FirebaseStoreManager.db.collection("players")
                .document(playerName)
                .update("sitting_out", false);
        return true;
    }

    public PlayerStatusType getPlayerStatus(Map<String, Object> player, Map<String, Object> game,
                                            Map<String, Object> hand, Map<String, Object> player_hand,
                                            Map<String, Object> board) {
        if (player == null) {
            return PlayerStatusType.ELIMINATED;
        }

        if (Boolean.parseBoolean(player.get("sitting_out").toString())) {
            return PlayerStatusType.SIT_OUT_GAME;
        }

        if (!Boolean.parseBoolean(game.get("is_started").toString())) {
            return PlayerStatusType.NOT_STARTED;
        }

        if (hand == null) {
            return PlayerStatusType.SEATING;
        }
        List<Integer> players = (List<Integer>) hand.get("players");
        if (!players.contains(player_hand.get("player_id"))) {
            if (Integer.parseInt(player.get("chips").toString()) <= 0) {
                return PlayerStatusType.ELIMINATED;
            }
            return PlayerStatusType.SIT_OUT;
        }

        if (hand.get("current_to_act") == null) {
            if (players.size() == 1) {
                return PlayerStatusType.WON_HAND;
            }
            List<Map<String, Object>> hand_players = new ArrayList<>();
            hand_players.add(player_hand);
            Map<Integer, Integer> winners = PlayerUtil.getAmountWonInHandForAllPlayers(hand, board, hand_players);
            if (winners != null && winners.containsKey(player)) {
                return PlayerStatusType.WON_HAND;
            } else {
                return PlayerStatusType.LOST_HAND;
            }
        }

        if (Integer.parseInt(player.get("chips").toString()) <= 0) {
            return PlayerStatusType.ALL_IN;
        }

        if (!player.get("player_id").equals(hand.get("current_to_act"))) {
            return PlayerStatusType.WAITING;
        }

        if (Integer.parseInt(hand.get("total_bet_amount").toString()) > Integer.parseInt(player_hand.get("round_bet_amount").toString())) {
            return PlayerStatusType.ACTION_TO_CALL;
        } else if (Integer.parseInt(player_hand.get("round_bet_amount").toString()) > 0) {
            return PlayerStatusType.ACTION_TO_CHECK;
        } else {
            return PlayerStatusType.ACTION_TO_CHECK;
        }
    }

    public PlayerStatus buildPlayerStatus(Map<String, Object> player, Map<String, Object> game,
                                          Map<String, Object> hand, Map<String, Object> player_hand,
                                          Map<String, Object> board) {
        PlayerStatus results = new PlayerStatus();
        PlayerStatusType playerStatus = getPlayerStatus(player, game, hand, player_hand, board);
        if (playerStatus == PlayerStatusType.WAITING && GameUtil.getGameStatus(game, hand, board) == GameStatus.PREFLOP) {
            if (((List<Integer>) hand.get("players")).size() == 1) {
                playerStatus = PlayerStatusType.WON_HAND;
            } else if (Integer.parseInt(player.get("player_id").toString()) == GameService.getPlayerInSB(hand, game)) {
                playerStatus = PlayerStatusType.POST_SB;
            } else if (Integer.parseInt(player.get("player_id").toString()) == GameService.getPlayerInBB(hand, game)) {
                playerStatus = PlayerStatusType.POST_BB;
            }
        }
        results.setStatus(playerStatus);

        results.setChips(Integer.parseInt(player.get("chips").toString()));
        Map<String, Object> gameStructure = (Map<String, Object>) game.get("game_structure");
        if (gameStructure.get("current_blind_level") != null) {
            results.setSmallBlind(BlindLevel.parseBlindLevel(gameStructure.get("current_blind_level").toString()).getSmallBlind());
            results.setBigBlind(BlindLevel.parseBlindLevel(gameStructure.get("current_blind_level").toString()).getBigBlind());
        }
        if (Boolean.parseBoolean(game.get("is_started").toString())) {
            results.setCard1(Card.getCard(player_hand.get("card1").toString()));
            results.setCard2(Card.getCard(player_hand.get("card2").toString()));
            results.setAmountBetRound(Integer.parseInt(player_hand.get("round_bet_amount").toString()));

            int toCall = Integer.parseInt(hand.get("total_bet_amount").toString()) - Integer.parseInt(player_hand.get("round_bet_amount").toString());
            toCall = Math.min(toCall, Integer.parseInt(player.get("chips").toString()));
            if (toCall > 0) {
                results.setAmountToCall(toCall);
            }
        }
        return results;
    }
}
