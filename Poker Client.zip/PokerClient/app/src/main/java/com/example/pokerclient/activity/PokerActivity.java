package com.example.pokerclient.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.pokerclient.R;
import com.example.pokerclient.lib.card.Card;
import com.example.pokerclient.lib.player.PlayerStatus;
import com.example.pokerclient.lib.player.PlayerStatusHandler;
import com.example.pokerclient.lib.player.PlayerStatusType;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.manager.PreferencesManager;
import com.example.pokerclient.service.GameService;
import com.example.pokerclient.service.PlayerActionService;
import com.example.pokerclient.service.PokerHandService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokerActivity extends Activity implements PlayerStatusHandler, OnCompleteListener<QuerySnapshot> {
    public static final int GAME_SELECTION_REQUEST = 8009;
    public static final long UPDATE_SLEEP_TIME = 3000;

    private boolean isFinished;
    private StatusUpdateTimer statusUpdateTimer;
    private int serverConnectFailCount;
    private AlertDialog serverErrorDialog;
    public PlayerStatus lastPlayerStatus;
    private PlayerActionService playerActionService;
    public GameService gameService;
    private boolean card1Shown;
    private boolean card2Shown;
    private int game_id;
    private boolean actionListenerBoardStatus = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poker);

        View betView = findViewById(R.id.action_layout);
        betView.setVisibility(ViewGroup.GONE);
        View cardLayout = findViewById(R.id.cards_layout);
        cardLayout.setVisibility(ViewGroup.INVISIBLE);

        card1Shown = false;
        card2Shown = false;
        playerActionService = new PlayerActionService(this);
        gameService = new GameService(this);
        findViewById(R.id.status_text).setKeepScreenOn(true);

        EditText betAmountField = (EditText) findViewById(R.id.input_bet_amount);
        final Context context = this;
        betAmountField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                int newBetAmount;
                try {
                    newBetAmount = Integer.valueOf(editable.toString());
                } catch (Exception e) {
                    return;
                }
                int amountToCall = 0;
                if (lastPlayerStatus != null) {
                    amountToCall = lastPlayerStatus.getAmountToCall();
                    amountToCall += lastPlayerStatus.getAmountBetRound();
                }
                Button raiseButton = (Button) findViewById(R.id.btn_raise);
                raiseButton.setText(String.format(
                        PokerActivity.this.getString(R.string.btn_raise_formatted),
                        String.valueOf(newBetAmount + amountToCall)));
                Button betButton = (Button) findViewById(R.id.btn_bet);
                betButton.setText(String.format(
                        PokerActivity.this.getString(R.string.btn_bet_formatted), String.valueOf(newBetAmount)));
                FirebaseStoreManager.updatePlayerHandRoundBetAmount(PreferencesManager.getUsername(context), newBetAmount);
            }
        });
        game_id = PreferencesManager.getGameId(this);
        gameService.gameController();
        gameService.handController();
    }

    public void showCard1(View view) {
        if (lastPlayerStatus == null || lastPlayerStatus.getCard1() == null) {
            return;
        }
        ImageView card1 = (ImageView) findViewById(R.id.card1);
        if (!card1Shown) {
            card1.setImageResource(lastPlayerStatus.getCard1().getDrawable());
        } else {
            card1.setImageResource(R.drawable.card_bg);
        }
        card1Shown = !card1Shown;
    }

    public void showCard2(View view) {
        if (lastPlayerStatus == null || lastPlayerStatus.getCard2() == null) {
            return;
        }
        ImageView card2 = (ImageView) findViewById(R.id.card2);
        if (!card2Shown) {
            card2.setImageResource(lastPlayerStatus.getCard2().getDrawable());
        } else {
            card2.setImageResource(R.drawable.card_bg);
        }
        card2Shown = !card2Shown;
    }

    public void check(View view) {
        int gameId = PreferencesManager.getGameId(this);
        int playerId = PreferencesManager.getPlayerId(this);
        String gameName = PreferencesManager.getGameName(this);
        FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().getDocuments().size() == 0) {
                                return;
                            }
                            Map<String, Object> game = task.getResult().getDocuments().get(0).getData();

                            FirebaseStoreManager.db.collection("players")
                                    .whereEqualTo("game_id", gameId)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                List<Map<String, Object>> players = new ArrayList<>();
                                                List<Integer> players_id = new ArrayList<>();
                                                for (DocumentSnapshot playerDoc : task.getResult()) {
                                                    players.add(playerDoc.getData());
                                                    players_id.add(Integer.parseInt(playerDoc.get("player_id").toString()));
                                                }

                                                FirebaseStoreManager.db.collection("player_hand")
                                                        .whereEqualTo("hand_id", game.get("current_hand"))
                                                        .get()
                                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                if (task.isSuccessful()) {
                                                                    List<Map<String, Object>> players_hand = new ArrayList<>();
                                                                    for (DocumentSnapshot playerHandDoc : task.getResult()) {
                                                                        players_hand.add(playerHandDoc.getData());
                                                                    }
                                                                    FirebaseStoreManager.db.collection("hand")
                                                                            .whereEqualTo("hand_id", game.get("current_hand"))
                                                                            .get()
                                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                    if (task.isSuccessful()) {
                                                                                        if (task.getResult().getDocuments().size() == 0) {
                                                                                            return;
                                                                                        }
                                                                                        Map<String, Object> hand = task.getResult().getDocuments().get(0).getData();
                                                                                        boolean check = playerActionService.check(players, players_hand, hand, playerId, lastPlayerStatus, gameName);
                                                                                        actionResponse(check);

                                                                                    }
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });

    }

    public void bet(View view) {
        long gameId = PreferencesManager.getGameId(this);
        int playerId = PreferencesManager.getPlayerId(this);
        String gameName = PreferencesManager.getGameName(this);
        EditText betText = (EditText) findViewById(R.id.input_bet_amount);
        try {
            int betAmount = Integer.parseInt(betText.getText().toString());
            FirebaseStoreManager.db.collection("game")
                    .whereEqualTo("game_id", gameId)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                if (task.getResult().getDocuments().size() == 0) {
                                    return;
                                }
                                Map<String, Object> game = task.getResult().getDocuments().get(0).getData();

                                FirebaseStoreManager.db.collection("players")
                                        .whereEqualTo("game_id", gameId)
                                        .get()
                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                if (task.isSuccessful()) {
                                                    List<Map<String, Object>> players = new ArrayList<>();
                                                    List<Integer> players_id = new ArrayList<>();
                                                    for (DocumentSnapshot playerDoc : task.getResult()) {
                                                        players.add(playerDoc.getData());
                                                        players_id.add(Integer.parseInt(playerDoc.get("player_id").toString()));
                                                    }

                                                    FirebaseStoreManager.db.collection("player_hand")
                                                            .whereEqualTo("hand_id", game.get("current_hand"))
                                                            .get()
                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                @Override
                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                    if (task.isSuccessful()) {
                                                                        List<Map<String, Object>> players_hand = new ArrayList<>();
                                                                        for (DocumentSnapshot playerHandDoc : task.getResult()) {
                                                                            players_hand.add(playerHandDoc.getData());
                                                                        }
                                                                        FirebaseStoreManager.db.collection("hand")
                                                                                .whereEqualTo("hand_id", game.get("current_hand"))
                                                                                .get()
                                                                                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                    @Override
                                                                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                        if (task.isSuccessful()) {
                                                                                            if (task.getResult().getDocuments().size() == 0) {
                                                                                                return;
                                                                                            }
                                                                                            Map<String, Object> hand = task.getResult().getDocuments().get(0).getData();
                                                                                            actionResponse(playerActionService.bet(players, players_hand, hand, playerId, betAmount, gameName));
                                                                                            betText.setText("0");
                                                                                        }
                                                                                    }
                                                                                });
                                                                    }
                                                                }
                                                            });
                                                }
                                            }
                                        });
                            }
                        }
                    });

        } catch (
                Exception e) {
            Toast.makeText(this, getString(R.string.bad_bet), Toast.LENGTH_SHORT).show();
        }
    }

    public void fold(View view) {
        int gameId = PreferencesManager.getGameId(this);
        int playerId = PreferencesManager.getPlayerId(this);
        String gameName = PreferencesManager.getGameName(this);
        FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().getDocuments().size() == 0) {
                                return;
                            }
                            Map<String, Object> game = task.getResult().getDocuments().get(0).getData();

                            FirebaseStoreManager.db.collection("players")
                                    .whereEqualTo("game_id", gameId)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                List<Map<String, Object>> players = new ArrayList<>();
                                                List<Integer> players_id = new ArrayList<>();
                                                for (DocumentSnapshot playerDoc : task.getResult()) {
                                                    players.add(playerDoc.getData());
                                                    players_id.add(Integer.parseInt(playerDoc.get("player_id").toString()));
                                                }

                                                FirebaseStoreManager.db.collection("player_hand")
                                                        .whereEqualTo("hand_id", game.get("current_hand"))
                                                        .get()
                                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                if (task.isSuccessful()) {
                                                                    List<Map<String, Object>> players_hand = new ArrayList<>();
                                                                    for (DocumentSnapshot playerHandDoc : task.getResult()) {
                                                                        players_hand.add(playerHandDoc.getData());
                                                                    }
                                                                    FirebaseStoreManager.db.collection("hand")
                                                                            .whereEqualTo("hand_id", game.get("current_hand"))
                                                                            .get()
                                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                    if (task.isSuccessful()) {
                                                                                        if (task.getResult().getDocuments().size() == 0) {
                                                                                            return;
                                                                                        }
                                                                                        Map<String, Object> hand = task.getResult().getDocuments().get(0).getData();
                                                                                        actionResponse(playerActionService.fold(players, players_hand, hand, playerId, gameName));
                                                                                    }
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });

    }

    public void call(View view) {
        int gameId = PreferencesManager.getGameId(this);
        int playerId = PreferencesManager.getPlayerId(this);
        String gameName = PreferencesManager.getGameName(this);
        FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().getDocuments().size() == 0) {
                                return;
                            }
                            Map<String, Object> game = task.getResult().getDocuments().get(0).getData();

                            FirebaseStoreManager.db.collection("players")
                                    .whereEqualTo("game_id", gameId)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                            if (task.isSuccessful()) {
                                                List<Map<String, Object>> players = new ArrayList<>();
                                                List<Integer> players_id = new ArrayList<>();
                                                for (DocumentSnapshot playerDoc : task.getResult()) {
                                                    players.add(playerDoc.getData());
                                                    players_id.add(Integer.parseInt(playerDoc.get("player_id").toString()));
                                                }

                                                FirebaseStoreManager.db.collection("player_hand")
                                                        .whereEqualTo("hand_id", game.get("current_hand"))
                                                        .get()
                                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                if (task.isSuccessful()) {
                                                                    List<Map<String, Object>> players_hand = new ArrayList<>();
                                                                    for (DocumentSnapshot playerHandDoc : task.getResult()) {
                                                                        players_hand.add(playerHandDoc.getData());
                                                                    }
                                                                    FirebaseStoreManager.db.collection("hand")
                                                                            .whereEqualTo("hand_id", game.get("current_hand"))
                                                                            .get()
                                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                                                    if (task.isSuccessful()) {
                                                                                        if (task.getResult().getDocuments().size() == 0) {
                                                                                            return;
                                                                                        }
                                                                                        Map<String, Object> hand = task.getResult().getDocuments().get(0).getData();
                                                                                        actionResponse(playerActionService.call(players, players_hand, hand, playerId, gameName));
                                                                                    }
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    public void changeBet3x(View view) {
        EditText betAmountField = (EditText) findViewById(R.id.input_bet_amount);
        int amountToCall = lastPlayerStatus.getAmountToCall();
        if (amountToCall != 0) {
            betAmountField.setText("" + (amountToCall + lastPlayerStatus.getAmountBetRound()) * 2);
        } else {
            Log.d("Poker Android", "Big Blind: " + lastPlayerStatus.getBigBlind());
            betAmountField.setText("" + lastPlayerStatus.getBigBlind() * 3);
        }
    }

    public void changeBet4x(View view) {
        EditText betAmountField = (EditText) findViewById(R.id.input_bet_amount);
        int amountToCall = lastPlayerStatus.getAmountToCall();
        if (amountToCall != 0) {
            betAmountField.setText("" + (amountToCall + lastPlayerStatus.getAmountBetRound()) * 3);
        } else {
            Log.d("Poker Android", "Big Blind: " + lastPlayerStatus.getBigBlind());
            betAmountField.setText("" + lastPlayerStatus.getBigBlind() * 4);
        }
    }

    public void sitIn(View view) {
        String playerName = PreferencesManager.getUsername(this);
        actionResponse(playerActionService.sitIn(playerName));
    }

    @Override
    protected void onResume() {
        super.onResume();

        //Use the isFinished flag for low memory case (possibly android bug)
        if (isFinished) {
            return;
        }
        if (PreferencesManager.getGameId(this) == 0 || PreferencesManager.getPlayerId(this) == 0) {
            startActivityForResult(new Intent(this, PokerActivity.class), GAME_SELECTION_REQUEST);
        } else {
            statusUpdateTimer = new StatusUpdateTimer();
            statusUpdateTimer.execute();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (statusUpdateTimer != null) {
            statusUpdateTimer.cancel(true);
        }
        playerStatusTask();
    }

    public void playerStatusTask() {
        int gameId = PreferencesManager.getGameId(this);
        int playerId = PreferencesManager.getPlayerId(this);
        String playerName = PreferencesManager.getUsername(this);
        FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", gameId)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> gameTask) {
                        if (gameTask.isSuccessful()) {
                            if (gameTask.getResult().getDocuments().size() == 0) {
                                return;
                            }
                            DocumentSnapshot gameDoc = gameTask.getResult().getDocuments().get(0);
                            FirebaseStoreManager.db.collection("players")
                                    .whereEqualTo("name", playerName)
                                    .get()
                                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<QuerySnapshot> playerTask) {
                                            if (playerTask.isSuccessful()) {
                                                if (playerTask.getResult().getDocuments().size() == 0) {
                                                    return;
                                                }
                                                DocumentSnapshot playerDoc = playerTask.getResult().getDocuments().get(0);
                                                FirebaseStoreManager.db.collection("hand")
                                                        .whereEqualTo("hand_id", gameDoc.get("current_hand"))
                                                        .get()
                                                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<QuerySnapshot> handTask) {
                                                                if (handTask.isSuccessful() && handTask.getResult().size() > 0) {
                                                                    if (handTask.getResult().getDocuments().size() == 0) {
                                                                        return;
                                                                    }
                                                                    DocumentSnapshot handDoc = handTask.getResult().getDocuments().get(0);
                                                                    FirebaseStoreManager.db.collection("player_hand")
                                                                            .whereEqualTo("player_id", playerDoc.get("player_id"))
                                                                            .get()
                                                                            .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                @Override
                                                                                public void onComplete(@NonNull Task<QuerySnapshot> playerHandTask) {
                                                                                    if (playerHandTask.isSuccessful()) {
                                                                                        if (playerHandTask.getResult().getDocuments().size() == 0) {
                                                                                            return;
                                                                                        }
                                                                                        DocumentSnapshot playerHandDoc = playerHandTask.getResult().getDocuments().get(0);
                                                                                        FirebaseStoreManager.db.collection("board")
                                                                                                .whereEqualTo("board_id", gameDoc.get("game_id"))
                                                                                                .get()
                                                                                                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                                                                    @Override
                                                                                                    public void onComplete(@NonNull Task<QuerySnapshot> boardTask) {
                                                                                                        if (boardTask.isSuccessful()) {
                                                                                                            if (boardTask.getResult().getDocuments().size() == 0) {
                                                                                                                return;
                                                                                                            }
                                                                                                            DocumentSnapshot boardDoc = boardTask.getResult().getDocuments().get(0);
                                                                                                            PlayerStatus status = playerActionService.buildPlayerStatus(playerDoc.getData(), gameDoc.getData(),
                                                                                                                    handDoc.getData(), playerHandDoc.getData(), boardDoc.getData());

                                                                                                            updatePlayerStatus(status);

                                                                                                        }
                                                                                                    }
                                                                                                });
                                                                                    }
                                                                                }
                                                                            });
                                                                }
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });
    }

    @Override
    public void onDestroy() {
        System.out.println("aaaaaaaaaaaaaaaaaaaaaaaa");
        if (PreferencesManager.getGameId(this) > 0) {
            System.out.println("aaaaaaaaaaaaaaaaaaaaaaaa2");
            leave();
        }
        super.onDestroy();
    }

    private void leave() {
        FirebaseStoreManager.db.collection("game")
                .whereEqualTo("game_id", game_id)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot doc : task.getResult()) {
                                Map<String, Object> game = doc.getData();
                                int remaining = Integer.parseInt(game.get("players_remaining").toString());
                                game.put("players_remaining", remaining > 0 ? remaining - 1 : 0);
                                FirebaseStoreManager.db.collection("game")
                                        .document(doc.getId())
                                        .update(game);

                                Map<String, Object> updates = new HashMap<>();
                                updates.put("game", 0);
                                updates.put("chips", 0);
                                String playername = PreferencesManager.getUsername(getBaseContext());
                                FirebaseStoreManager.db.collection("players")
                                        .document(playername)
                                        .update(updates);
                                FirebaseStoreManager.db.collection("player_hand").document(playername).delete();
                                if (remaining == 0) {
                                    FirebaseStoreManager.db.collection("hand").document(doc.getId()).delete();
                                    FirebaseStoreManager.db.collection("board").document(doc.getId()).delete();
                                }
                                PreferencesManager.setGameId(0, getBaseContext());
                                PreferencesManager.setPlayerId(0, getBaseContext());
                                PreferencesManager.setGameName("", getBaseContext());
                            }
                        }
                    }
                });
        gameService.destroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == GAME_SELECTION_REQUEST && resultCode != Activity.RESULT_OK) {
            isFinished = true;
            finish();
        } else if (requestCode == GAME_SELECTION_REQUEST) {
            statusUpdateTimer = new StatusUpdateTimer();
            statusUpdateTimer.execute();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void updatePlayerStatus(PlayerStatus playerStatus) {
        if (playerStatus == null || playerStatus.getStatus() == null) {
            Log.e("Poker", "Server Error");

            serverConnectFailCount++;
            //If we fail connecting to the server enough times, shut it down
            if (serverConnectFailCount > 3) {
                if (serverErrorDialog != null) {
                    serverErrorDialog.dismiss();
                }
                serverErrorDialog = new AlertDialog.Builder(this)
                        .setTitle(getString(R.string.error))
                        .setMessage(getString(R.string.no_connection))
                        .setPositiveButton(getString(R.string.ok), null).create();
                serverErrorDialog.show();
                statusUpdateTimer.cancel(true);
            } else {
                Toast.makeText(this, getString(R.string.server_error), Toast.LENGTH_SHORT).show();
            }
            return;
        }
        serverConnectFailCount = 0;

        setupUI(playerStatus);

        lastPlayerStatus = playerStatus;
    }

    @Override
    public void actionResponse(boolean success) {
        if (!success) {
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.warning))
                    .setMessage(getString(R.string.not_allowed))
                    .setPositiveButton(getString(R.string.ok), null)
                    .create().show();
        } else {
            lastPlayerStatus.setStatus(PlayerStatusType.WAITING);
            ((EditText) findViewById(R.id.input_bet_amount)).setText("" + lastPlayerStatus.getBigBlind());
            setupUI(lastPlayerStatus);

        }
    }

    private void setupUI(PlayerStatus playerStatus) {
        if (lastPlayerStatus != null && playerStatus.getCard1() != lastPlayerStatus.getCard1() && card1Shown) {
            showCard1(null);
        }
        if (lastPlayerStatus != null && playerStatus.getCard2() != lastPlayerStatus.getCard2() && card2Shown) {
            showCard2(null);
        }

        if ((lastPlayerStatus == null || lastPlayerStatus.getStatus() == null ||
                (lastPlayerStatus.getStatus() != PlayerStatusType.ACTION_TO_CALL &&
                        lastPlayerStatus.getStatus() != PlayerStatusType.ACTION_TO_CHECK))
                && (playerStatus.getStatus() == PlayerStatusType.ACTION_TO_CALL ||
                playerStatus.getStatus() == PlayerStatusType.ACTION_TO_CHECK)) {
            Vibrator v = (Vibrator) getSystemService(Activity.VIBRATOR_SERVICE);
            v.vibrate(600);
            actionListenerBoard();
        }

        setupInfoFields(playerStatus);
        setupBetFields(playerStatus);

        View sitOutLayout = findViewById(R.id.sit_out_layout);
        if (playerStatus.getStatus() == PlayerStatusType.SIT_OUT_GAME) {
            sitOutLayout.setVisibility(ViewGroup.VISIBLE);
        } else {
            sitOutLayout.setVisibility(ViewGroup.GONE);
        }
    }

    private void setupInfoFields(PlayerStatus playerStatus) {
        TextView statusText = (TextView) findViewById(R.id.status_text);
        String statusString = getString(playerStatus.getStatus().getStringResource());
        if (playerStatus.getStatus() == PlayerStatusType.POST_SB) {
            statusString += " (" + playerStatus.getSmallBlind() + ")";
        } else if (playerStatus.getStatus() == PlayerStatusType.POST_BB) {
            statusString += " (" + playerStatus.getBigBlind() + ")";
        }
        statusText.setText(statusString);

        RelativeLayout cardLayout = (RelativeLayout) findViewById(R.id.cards_layout);
        if (playerStatus.getCard1() != null) {
            cardLayout.setVisibility(ViewGroup.VISIBLE);
        } else {
            cardLayout.setVisibility(ViewGroup.INVISIBLE);
        }
        ((TextView) findViewById(R.id.txt_chip_amount)).setText("" + playerStatus.getChips());
    }

    private void setupBetFields(PlayerStatus playerStatus) {
        View betView = findViewById(R.id.action_layout);

        if (playerStatus.getStatus() != PlayerStatusType.ACTION_TO_CALL &&
                playerStatus.getStatus() != PlayerStatusType.ACTION_TO_CHECK) {
            betView.setVisibility(ViewGroup.GONE);
            return;
        }

        betView.setVisibility(ViewGroup.VISIBLE);
        if (playerStatus.getStatus() == PlayerStatusType.ACTION_TO_CHECK) {
            findViewById(R.id.button_call_layout).setVisibility(ViewGroup.GONE);
            findViewById(R.id.button_check_layout).setVisibility(ViewGroup.VISIBLE);
        } else {
            findViewById(R.id.button_call_layout).setVisibility(ViewGroup.VISIBLE);
            findViewById(R.id.button_check_layout).setVisibility(ViewGroup.GONE);
        }

        TextView amountToCall = (TextView) findViewById(R.id.txt_bet_amount);
        if (playerStatus.getAmountToCall() > 0) {
            amountToCall.setText("" + playerStatus.getAmountToCall());
        } else {
            amountToCall.setText("0");
        }

        EditText betAmount = (EditText) findViewById(R.id.input_bet_amount);
        if (betAmount.getText().toString().equals("0") || betAmount.getText().toString().equals("")) {
            betAmount.setText("" + Math.max(playerStatus.getAmountToCall(), playerStatus.getBigBlind()));
        }
    }

    public void blackChipAnimWon() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(70, 70);
        List<ImageView> chips = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            ImageView blackChip = new ImageView(this);
            blackChip.setId(i);

            int x = (int) Math.round(Math.random() * width);
            if (x >= width) {
                x -= 30;
            }
            int y = (int) Math.round(Math.random() * height);
            if (y >= height) {
                y -= 30;
            }

            blackChip.setX(x);
            blackChip.setY(y);
            blackChip.setBackgroundResource(R.drawable.black_chip_effect);
            addContentView(blackChip, lp);
            AnimationDrawable blackChipAnimation = (AnimationDrawable) blackChip.getBackground();
            blackChipAnimation.start();
            chips.add(blackChip);

        }

        new CountDownTimer(2000, 2000) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                for (ImageView iv : chips) {
                    ViewGroup rootView = (ViewGroup) findViewById(android.R.id.content);
                    rootView.removeView(iv);
                }
            }
        }.start();

    }

    private void sendPlayerStatusRequest() {
        playerStatusTask();
    }

    public void actionListenerBoard() {
        if (actionListenerBoardStatus) {
            return;
        }
        actionListenerBoardStatus = true;
        String gameName = PreferencesManager.getGameName(this);
        FirebaseStoreManager.db.collection("board")
                .document(gameName)
                .addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            return;
                        }

                        Map<String, Object> board = value.getData();
                        ImageView sharedCard1 = (ImageView) findViewById(R.id.shared_card1);
                        ImageView sharedCard2 = (ImageView) findViewById(R.id.shared_card2);
                        ImageView sharedCard3 = (ImageView) findViewById(R.id.shared_card3);
                        ImageView sharedCard4 = (ImageView) findViewById(R.id.shared_card4);
                        ImageView sharedCard5 = (ImageView) findViewById(R.id.shared_card5);
                        if (board.get("flop1") == null) {
                            sharedCard1.setVisibility(View.INVISIBLE);
                            sharedCard2.setVisibility(View.INVISIBLE);
                            sharedCard3.setVisibility(View.INVISIBLE);
                            sharedCard4.setVisibility(View.INVISIBLE);
                            sharedCard5.setVisibility(View.INVISIBLE);
                        }
                        if (board.get("flop1") != null && board.get("turn") == null) {
                            sharedCard1.setImageResource(Card.getCard(board.get("flop1").toString()).getDrawable());
                            sharedCard1.setVisibility(View.VISIBLE);

                            sharedCard2.setImageResource(Card.getCard(board.get("flop2").toString()).getDrawable());
                            sharedCard2.setVisibility(View.VISIBLE);

                            sharedCard3.setImageResource(Card.getCard(board.get("flop3").toString()).getDrawable());
                            sharedCard3.setVisibility(View.VISIBLE);
                        }
                        if (board.get("turn") != null && board.get("river") == null) {
                            sharedCard4.setImageResource(Card.getCard(board.get("turn").toString()).getDrawable());
                            sharedCard4.setVisibility(View.VISIBLE);
                        }
                        if (board.get("river") != null) {
                            sharedCard5.setImageResource(Card.getCard(board.get("river").toString()).getDrawable());
                            sharedCard5.setVisibility(View.VISIBLE);
                        }
                    }
                });
    }

    @Override
    public void onBackPressed() {
        leave();
        super.onBackPressed();  // Invoca al método
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.poker, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                startActivity(new Intent(this, SettingsActivity.class));
                break;
            case R.id.action_leave:
                PreferencesManager.setGameId(0, this);
                PreferencesManager.setPlayerId(0, this);
                startActivityForResult(new Intent(this, GameSelectionActivity.class), GAME_SELECTION_REQUEST);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    @Override
    public void onComplete(@NonNull Task<QuerySnapshot> task) {
        if (task.isSuccessful()) {
            int currentQuery = FirebaseStoreManager.QUERY;
            if (currentQuery == FirebaseStoreManager.GET_GAME_BY_ID) {

            }
        }
    }

    private class StatusUpdateTimer extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            while (!this.isCancelled()) {
                this.publishProgress();
                try {
                    Thread.sleep(UPDATE_SLEEP_TIME);
                } catch (Exception e) {
                    //Don't care
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
            sendPlayerStatusRequest();
        }
    }
}
