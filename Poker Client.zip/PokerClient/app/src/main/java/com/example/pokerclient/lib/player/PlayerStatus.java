package com.example.pokerclient.lib.player;

import com.example.pokerclient.lib.card.Card;

public class PlayerStatus {
    private PlayerStatusType status;
    private int chips;
    private int smallBlind;
    private int bigBlind;
    private Card card1;
    private Card card2;
    private int amountBetRound;
    private int amountToCall;

    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof PlayerStatus)){
            return false;
        }
        PlayerStatus p = (PlayerStatus) o;
        return this.status == p.getStatus() && this.chips == p.getChips()
                &&this.card1.equals(p.getCard1()) && this.card2.equals(p.getCard2());
    }

    @Override
    public int hashCode(){
        return status.hashCode() + this.chips +this.card1.hashCode() + this.card2.hashCode();
    }

    public PlayerStatusType getStatus() {
        return status;
    }
    public void setStatus(PlayerStatusType status) {
        this.status = status;
    }
    public int getChips() {
        return chips;
    }
    public void setChips(int chips) {
        this.chips = chips;
    }
    public int getSmallBlind() {
        return smallBlind;
    }
    public void setSmallBlind(int smallBlind) {
        this.smallBlind = smallBlind;
    }
    public int getBigBlind() {
        return bigBlind;
    }
    public void setBigBlind(int bigBlind) {
        this.bigBlind = bigBlind;
    }
    public Card getCard1() {
        return card1;
    }
    public void setCard1(Card card1) {
        this.card1 = card1;
    }
    public Card  getCard2() {
        return card2;
    }
    public void setCard2(Card card2) {
        this.card2 = card2;
    }
    public int getAmountBetRound() {
        return amountBetRound;
    }
    public void setAmountBetRound(int amountBetRound) {
        this.amountBetRound = amountBetRound;
    }
    public int getAmountToCall() {
        return amountToCall;
    }
    public void setAmountToCall(int amountToCall) {
        this.amountToCall = amountToCall;
    }
}
