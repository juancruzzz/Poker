package com.example.pokerclient.lib.player;

public interface PlayerStatusHandler {
    public void updatePlayerStatus(PlayerStatus playerStatus);

    public void actionResponse(boolean success);
}