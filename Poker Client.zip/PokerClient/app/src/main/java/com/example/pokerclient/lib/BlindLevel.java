package com.example.pokerclient.lib;

public enum BlindLevel {

    BLIND_10_20(10, 20),
    BLIND_15_30(15, 30),
    BLIND_20_40(20, 40),
    BLIND_25_50(25, 50),
    BLIND_30_60(30, 60),
    BLIND_40_80(40, 80),
    BLIND_50_100(50, 100),
    BLIND_60_120(60, 120),
    BLIND_75_150(75, 150),
    BLIND_80_160(80, 160),
    BLIND_100_200(100, 200),
    BLIND_120_240(120, 240),
    BLIND_150_300(150, 300),
    BLIND_200_400(200, 400),
    BLIND_250_500(250, 500),
    BLIND_300_600(300, 600),
    BLIND_400_800(400, 800),
    BLIND_500_1000(500, 1000),
    BLIND_600_1200(600, 1200),
    BLIND_700_1400(700, 1400),
    BLIND_800_1600(800, 1600),
    BLIND_900_1800(900, 1800),
    BLIND_1000_2000(1000, 2000),
    BLIND_1200_2400(1200, 2400),
    BLIND_1500_3000(1500, 3000),
    BLIND_1600_3200(1600, 3200),
    BLIND_1800_3600(1800, 3600),
    BLIND_2000_4000(2000, 4000),
    BLIND_2500_5000(2500, 5000),
    BLIND_3000_6000(3000, 6000),
    BLIND_4000_8000(4000, 8000),
    BLIND_5000_10K(5000, 10000),
    BLIND_6000_12K(6000, 12000),
    BLIND_7000_14K(7000, 14000),
    BLIND_8000_16K(8000, 16000),
    BLIND_9000_18K(9000, 18000),
    BLIND_10K_20K(10000, 20000),
    BLIND_12K_24K(12000, 24000),
    BLIND_14K_28K(14000, 28000),
    BLIND_16K_32K(16000, 32000),
    BLIND_18K_36K(18000, 36000),
    BLIND_20K_40K(20000, 40000),
    BLIND_25K_50K(25000, 50000);

    private int smallBlind;
    private int bigBlind;

    BlindLevel(int smallBlind, int bigBlind) {
        this.smallBlind = smallBlind;
        this.bigBlind = bigBlind;
    }

    public int getSmallBlind() {
        return smallBlind;
    }

    public int getBigBlind() {
        return bigBlind;
    }

    public static BlindLevel parseBlindLevel(String blindLevel) {
        if (blindLevel.equals("BLIND_10_20")) {
            return BLIND_10_20;
        } else if (blindLevel.equals("BLIND_15_30")) {
            return BLIND_15_30;
        } else if (blindLevel.equals("BLIND_20_40")) {
            return BLIND_20_40;
        } else if (blindLevel.equals("BLIND_25_50")) {
            return BLIND_25_50;
        } else if (blindLevel.equals("BLIND_30_60")) {
            return BLIND_30_60;
        } else if (blindLevel.equals("BLIND_40_80")) {
            return BLIND_40_80;
        } else if (blindLevel.equals("BLIND_50_100")) {
            return BLIND_50_100;
        } else if (blindLevel.equals("BLIND_75_150")) {
            return BLIND_75_150;
        } else if (blindLevel.equals("BLIND_80_160")) {
            return BLIND_80_160;
        } else if (blindLevel.equals("BLIND_100_200")) {
            return BLIND_100_200;
        } else if (blindLevel.equals("BLIND_120_240")) {
            return BLIND_120_240;
        } else if (blindLevel.equals("BLIND_150_300")) {
            return BLIND_150_300;
        } else if (blindLevel.equals("BLIND_200_400")) {
            return BLIND_200_400;
        } else if (blindLevel.equals("BLIND_300_600")) {
            return BLIND_300_600;
        } else if (blindLevel.equals("BLIND_400_800")) {
            return BLIND_400_800;
        } else if (blindLevel.equals("BLIND_500_1000")) {
            return BLIND_500_1000;
        } else if (blindLevel.equals("BLIND_600_1200")) {
            return BLIND_600_1200;
        } else if (blindLevel.equals("BLIND_700_1400")) {
            return BLIND_700_1400;
        } else if (blindLevel.equals("BLIND_800_1600")) {
            return BLIND_800_1600;
        } else if (blindLevel.equals("BLIND_900_1800")) {
            return BLIND_900_1800;
        } else if (blindLevel.equals("BLIND_1000_2000")) {
            return BLIND_1000_2000;
        } else if (blindLevel.equals("BLIND_1200_2400")) {
            return BLIND_1200_2400;
        } else if (blindLevel.equals("BLIND_1500_3000")) {
            return BLIND_1500_3000;
        } else if (blindLevel.equals("BLIND_1600_3200")) {
            return BLIND_1600_3200;
        } else if (blindLevel.equals("BLIND_1800_3600")) {
            return BLIND_1800_3600;
        } else if (blindLevel.equals("BLIND_2000_4000")) {
            return BLIND_2000_4000;
        } else if (blindLevel.equals("BLIND_3000_6000")) {
            return BLIND_3000_6000;
        } else if (blindLevel.equals("BLIND_4000_8000")) {
            return BLIND_4000_8000;
        } else if (blindLevel.equals("BLIND_5000_10K")) {
            return BLIND_5000_10K;
        } else if (blindLevel.equals("BLIND_7000_14K")) {
            return BLIND_7000_14K;
        } else if (blindLevel.equals("BLIND_8000_16K")) {
            return BLIND_8000_16K;
        } else if (blindLevel.equals("BLIND_9000_18K")) {
            return BLIND_9000_18K;
        } else if (blindLevel.equals("BLIND_10K_20K")) {
            return BLIND_10K_20K;
        } else if (blindLevel.equals("BLIND_12K_24K")) {
            return BLIND_12K_24K;
        } else if (blindLevel.equals("BLIND_14K_28K")) {
            return BLIND_14K_28K;
        } else if (blindLevel.equals("BLIND_16K_32K")) {
            return BLIND_16K_32K;
        } else if (blindLevel.equals("BLIND_18K_36K")) {
            return BLIND_18K_36K;
        } else if (blindLevel.equals("BLIND_20K_40K")) {
            return BLIND_20K_40K;
        } else if (blindLevel.equals("BLIND_25K_50K")) {
            return BLIND_25K_50K;
        }
        return BLIND_10_20;

    }
}
