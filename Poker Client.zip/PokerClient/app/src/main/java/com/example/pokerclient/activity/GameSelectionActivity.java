package com.example.pokerclient.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.pokerclient.R;
import com.example.pokerclient.lib.GameStructure;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.manager.PreferencesManager;
import com.example.pokerclient.service.GameService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class GameSelectionActivity extends AppCompatActivity implements OnCompleteListener<QuerySnapshot>, View.OnClickListener {
    private ListView gameList;
    private Button openPopupNewGameButton;
    private Button closeSesion;
    private FirebaseAuth mAuth;

    // CREATE GAME
    private EditText gameNameText;
    private Spinner gameStructureSpinner;
    private EditText gameDescriptionText;
    private EditText gameMaxPlayersText;
    private EditText gameStartingChips;
    private EditText gameTimeInMins;
    private Button btnCreateGame;
    private boolean isGameNameExist = false;
    private GameStructure currentGame;
    private AlertDialog alertDialog;
    private int playerId;
    private String playerName;
    private ListenerRegistration listenerListGames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_selection);

        gameList = findViewById(R.id.game_list);
        openPopupNewGameButton = findViewById(R.id.open_popup_new_game_button);
        closeSesion = findViewById(R.id.close_session);
        mAuth = FirebaseAuth.getInstance();
        playerName = getIntent().getStringExtra("username");
        if (playerName == null) {
            mAuth.signOut();
        } else {
            FirebaseStoreManager.getPlayer(playerName).addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot doc = task.getResult();
                        playerId = Integer.parseInt(doc.get("player_id").toString());
                    }
                }
            });
        }
        snapshotListenerGames();
    }

    private void popupCreateGame() {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        TextView createGameLabel = new TextView(this);
        createGameLabel.setGravity(Gravity.CENTER);
        createGameLabel.setTextSize(20);
        createGameLabel.setTextColor(Color.WHITE);
        createGameLabel.setText(R.string.create_game_label);
        alert.setCustomTitle(createGameLabel);

        //LAYOUT PRINCIPAL
        LinearLayout linearLayoutBase = new LinearLayout(this);
        linearLayoutBase.setOrientation(LinearLayout.VERTICAL);
        LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.setMargins(16, 0, 0, 0);
        linearLayoutBase.setLayoutParams(params);

        //LAYOUT PARA NOMBRE DEL SERVIDOR
        LinearLayout linearLayoutServerName = new LinearLayout(this);
        linearLayoutServerName.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutServerName.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        TextView gameNameLabel = new TextView(this);
        gameNameLabel.setText(R.string.game_name_label);
        gameNameLabel.setLayoutParams(params);
        gameNameLabel.setTextColor(Color.WHITE);
        linearLayoutServerName.addView(gameNameLabel);

        InputFilter filter = new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                for (int i = start; i < end; ++i) {
                    if (!Pattern.compile("[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890]*").matcher(String.valueOf(source.charAt(i))).matches()) {
                        return "";
                    }
                }

                return null;
            }
        };
        gameNameText = new EditText(this);
        gameNameText.setFilters(new InputFilter[]{filter, new InputFilter.LengthFilter(20)});
        gameNameText.setWidth(500);
        linearLayoutServerName.addView(gameNameText);

        linearLayoutBase.addView(linearLayoutServerName);

        //LAYOUT PARA FORMATO DEL SERVIDOR
        LinearLayout linearLayoutServerFormat = new LinearLayout(this);
        linearLayoutServerFormat.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutServerFormat.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        TextView gameStructureLabel = new TextView(this);
        gameStructureLabel.setText(R.string.game_structure_label);
        gameStructureLabel.setLayoutParams(params);
        gameStructureLabel.setTextColor(Color.WHITE);
        linearLayoutServerFormat.addView(gameStructureLabel);

        gameStructureSpinner = new Spinner(this);
        FirebaseStoreManager.getGameStructure().addOnCompleteListener(this);
        linearLayoutServerFormat.addView(gameStructureSpinner);


        linearLayoutBase.addView(linearLayoutServerFormat);

        LinearLayout linearLayoutServerCreate2 = new LinearLayout(this);
        linearLayoutServerCreate2.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutServerCreate2.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        //LAYOUT PERSONALIZADO

        LinearLayout linearLayoutDescription = new LinearLayout(this);
        linearLayoutDescription.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutDescription.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        linearLayoutDescription.setVisibility(View.INVISIBLE);

        TextView gameDescriptionLabel = new TextView(this);
        gameDescriptionLabel.setText(R.string.game_description_label);
        gameDescriptionLabel.setLayoutParams(params);
        gameDescriptionLabel.setTextColor(Color.WHITE);
        linearLayoutDescription.addView(gameDescriptionLabel);

        gameDescriptionText = new EditText(this);
        gameDescriptionText.setWidth(500);
        linearLayoutDescription.addView(gameDescriptionText);
        linearLayoutBase.addView(linearLayoutDescription);


        LinearLayout linearLayoutMaxPlayers = new LinearLayout(this);
        linearLayoutMaxPlayers.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutMaxPlayers.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        linearLayoutMaxPlayers.setVisibility(View.INVISIBLE);

        TextView gameMaxPlayersLabel = new TextView(this);
        gameMaxPlayersLabel.setText(R.string.game_max_players_label);
        gameMaxPlayersLabel.setLayoutParams(params);
        gameMaxPlayersLabel.setTextColor(Color.WHITE);
        linearLayoutMaxPlayers.addView(gameMaxPlayersLabel);

        gameMaxPlayersText = new EditText(this);
        gameMaxPlayersText.setWidth(500);
        gameMaxPlayersText.setInputType(InputType.TYPE_CLASS_NUMBER);
        linearLayoutMaxPlayers.addView(gameMaxPlayersText);
        linearLayoutBase.addView(linearLayoutMaxPlayers);

        LinearLayout linearLayoutStartingChips = new LinearLayout(this);
        linearLayoutStartingChips.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutStartingChips.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        linearLayoutStartingChips.setVisibility(View.INVISIBLE);

        TextView gameStartingChipsLabel = new TextView(this);
        gameStartingChipsLabel.setText(R.string.game_starting_chips_label);
        gameStartingChipsLabel.setLayoutParams(params);
        gameStartingChipsLabel.setTextColor(Color.WHITE);
        linearLayoutStartingChips.addView(gameStartingChipsLabel);

        gameStartingChips = new EditText(this);
        gameStartingChips.setWidth(400);
        gameStartingChips.setInputType(InputType.TYPE_CLASS_NUMBER);
        linearLayoutStartingChips.addView(gameStartingChips);
        linearLayoutBase.addView(linearLayoutStartingChips);


        LinearLayout linearLayoutTimeInMins = new LinearLayout(this);
        linearLayoutTimeInMins.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutTimeInMins.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        linearLayoutTimeInMins.setVisibility(View.INVISIBLE);

        TextView gameTimeInMinsLabel = new TextView(this);
        gameTimeInMinsLabel.setText(R.string.game_time_in_mins_label);
        gameTimeInMinsLabel.setLayoutParams(params);
        gameTimeInMinsLabel.setTextColor(Color.WHITE);
        linearLayoutTimeInMins.addView(gameTimeInMinsLabel);

        gameTimeInMins = new EditText(this);
        gameTimeInMins.setWidth(400);
        gameTimeInMins.setInputType(InputType.TYPE_CLASS_NUMBER);
        linearLayoutTimeInMins.addView(gameTimeInMins);
        linearLayoutBase.addView(linearLayoutTimeInMins);


        //LAYOUT PARA CREAR EL SERVIDOR
        LinearLayout linearLayoutServerCreate = new LinearLayout(this);
        linearLayoutServerCreate.setOrientation(LinearLayout.HORIZONTAL);
        linearLayoutServerCreate.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        btnCreateGame = new Button(this);
        btnCreateGame.setText(R.string.game_create_button);
        btnCreateGame.setLayoutParams(params);
        btnCreateGame.setOnClickListener(this);

        linearLayoutServerCreate.addView(btnCreateGame);

        linearLayoutBase.addView(linearLayoutServerCreate);
        gameStructureSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if (position == 3) {
                    linearLayoutDescription.setVisibility(View.VISIBLE);
                    linearLayoutMaxPlayers.setVisibility(View.VISIBLE);
                    linearLayoutStartingChips.setVisibility(View.VISIBLE);
                    linearLayoutTimeInMins.setVisibility(View.VISIBLE);
                    linearLayoutServerCreate2.setLayoutParams(new LinearLayout.LayoutParams(0, 0));
                } else {
                    linearLayoutDescription.setVisibility(View.GONE);
                    linearLayoutMaxPlayers.setVisibility(View.GONE);
                    linearLayoutStartingChips.setVisibility(View.GONE);
                    linearLayoutTimeInMins.setVisibility(View.GONE);
                    linearLayoutServerCreate2.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }
        });

        alert.setView(linearLayoutBase);

        alertDialog = alert.create();
        alertDialog.show();
        alertDialog.getWindow().setLayout(Toolbar.LayoutParams.WRAP_CONTENT, Toolbar.LayoutParams.WRAP_CONTENT);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#BCFF0000")));
    }

    @Override
    public void onComplete(@NonNull Task<QuerySnapshot> task) {
        if (task.isSuccessful()) {
            int currentQuery = FirebaseStoreManager.QUERY;
            if (currentQuery == FirebaseStoreManager.GET_GAME_STRUCTURE) {
                List<String> list = new ArrayList<>();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    list.add(String.valueOf(document.get("description")));
                }
                list.add(getString(R.string.game_structure_custom));
                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list) {

                    public View getView(int position, View convertView, ViewGroup parent) {
                        View v = super.getView(position, convertView, parent);

                        ((TextView) v).setTextSize(16);
                        ((TextView) v).setTextColor(
                                getResources().getColorStateList(R.color.white)
                        );

                        return v;
                    }

                    public View getDropDownView(int position, View convertView, ViewGroup parent) {
                        View v = super.getDropDownView(position, convertView, parent);
                        v.setBackgroundColor(Color.RED);

                        ((TextView) v).setTextColor(
                                getResources().getColorStateList(R.color.white)
                        );

                        ((TextView) v).setGravity(Gravity.CENTER);

                        return v;
                    }
                };
                gameStructureSpinner.setAdapter(spinnerArrayAdapter);
            } else if (currentQuery == FirebaseStoreManager.GAME_NAME_EXIST) {
                isGameNameExist = task.getResult().size() > 0;
                onClick(btnCreateGame);
            } else if (currentQuery == FirebaseStoreManager.GET_GAME_STRUCTURE_BY_DESC) {
                Map<String, Object> gameStructure = task.getResult().getDocuments().get(0).getData();
                currentGame = new GameStructure(gameNameText.getText().toString(), gameStructure.get("description").toString(),
                        Integer.parseInt(gameStructure.get("max_players").toString()), Integer.parseInt(gameStructure.get("starting_chips").toString()),
                        Integer.parseInt(gameStructure.get("time_in_mins").toString()));
                FirebaseStoreManager.createGame(currentGame);
                alertDialog.hide();
            }
            if (currentQuery == FirebaseStoreManager.QUERY) {
                FirebaseStoreManager.QUERY = FirebaseStoreManager.NONE;
            }
        }
    }


    public void snapshotListenerGames() {
        try {
            listenerListGames = FirebaseStoreManager.db.collection("game")
                    .whereEqualTo("is_started", false)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot value,
                                            @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                return;
                            }
                            if (value == null) {
                                return;
                            }
                            List<String> gamesView = new ArrayList<>();
                            List<Integer> games = new ArrayList<>();
                            for (QueryDocumentSnapshot doc : value) {
                                Map<String, Object> gameStructure = (Map<String, Object>) doc.get("game_structure");
                                gamesView.add(doc.getString("name") + "\n" + gameStructure.get("description").toString() + " (" + doc.get("players_remaining") + "/" + gameStructure.get("max_players").toString() + ")");

                                games.add(Integer.parseInt(doc.get("game_id").toString()));
                            }

                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, gamesView) {

                                @Override
                                public View getView(int position, View convertView, ViewGroup parent) {
                                    View view = super.getView(position, convertView, parent);

                                    TextView textView = (TextView) view.findViewById(android.R.id.text1);

                                    textView.setTextColor(Color.WHITE);

                                    return view;
                                }
                            };
                            gameList.setAdapter(adapter);

                            gameList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    //CONSEGUIR DATOS DE LA PARTIDA
                                    //value.getDocuments().get(position)
                                    joinGame(games.get(position));
                                }
                            });
                        }
                    });
        } catch (Exception e) {

        }
    }

    @Override
    public void onClick(View v) {
        if (v == openPopupNewGameButton) {
            popupCreateGame();
        } else if (v == closeSesion) {
            mAuth.signOut();
            finish();
        } else if (v == btnCreateGame) {

            if (FirebaseStoreManager.QUERY == FirebaseStoreManager.NONE) {
                String serverName = gameNameText.getText().toString();
                if (serverName.isEmpty()) {
                    gameNameText.setError("Campo obligatorio");
                    return;
                }
                if (serverName.length() < 4) {
                    gameNameText.setError("Minimo 4 carácteres");
                    return;
                }
                FirebaseStoreManager.isExistGameName(serverName).addOnCompleteListener(this);
            } else if (FirebaseStoreManager.QUERY == FirebaseStoreManager.GAME_NAME_EXIST) {
                if (this.isGameNameExist) {
                    gameNameText.setError("Nombre no disponible");
                    return;
                }

                if (gameStructureSpinner.getSelectedItem() == null) {
                    return;
                }
                String gameStructureDesc = gameStructureSpinner.getSelectedItem().toString();
                if (gameStructureSpinner.getSelectedItemPosition() == 3) {
                    String desc = gameDescriptionText.getText().toString();
                    if (desc.isEmpty()) {
                        gameDescriptionText.setError("Campo obligatorio");
                        return;
                    }
                    if (desc.length() < 4) {
                        gameDescriptionText.setError("Minimo 4 carácteres");
                        return;
                    }
                    if (gameMaxPlayersText.getText().toString().isEmpty()) {
                        gameMaxPlayersText.setError("Campo obligatorio");
                        return;
                    }
                    int max_players = Integer.parseInt(gameMaxPlayersText.getText().toString());
                    if (max_players < 2) {
                        gameMaxPlayersText.setError("Minimo 2 jugadores");
                        return;
                    }

                    if (gameStartingChips.getText().toString().isEmpty()) {
                        gameStartingChips.setError("Campo obligatorio");
                        return;
                    }
                    int starting_chips = Integer.parseInt(gameStartingChips.getText().toString());
                    if (starting_chips < 1000) {
                        gameStartingChips.setError("Minimo 1000 fichas");
                        return;
                    }

                    if (gameTimeInMins.getText().toString().isEmpty()) {
                        gameTimeInMins.setError("Campo obligatorio");
                        return;
                    }
                    int time_in_mins = Integer.parseInt(gameTimeInMins.getText().toString());
                    if (time_in_mins < 10) {
                        gameTimeInMins.setError("Minimo 10 minutos");
                        return;
                    }
                    currentGame = new GameStructure(gameNameText.getText().toString(), desc, max_players, starting_chips, time_in_mins);

                    FirebaseStoreManager.createGame(currentGame);
                    alertDialog.hide();
                } else {
                    currentGame = new GameStructure(gameNameText.getText().toString());
                    FirebaseStoreManager.getGameStructureByDescription(gameStructureDesc).addOnCompleteListener(this);
                }
            }

        }
    }

    public void joinGame(int gameId) {
        GameService.addNewPlayerToGame(gameId).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot doc : task.getResult()) {
                        if (Boolean.parseBoolean(doc.get("is_started").toString())) {
                            return;
                            //throw new IllegalStateException("Partida en curso, no pueden unirse nuevos jugadores");
                        }
                        Map<String, ?> gameStructure = (Map<String, ?>) doc.get("game_structure");
                        int max_players = Integer.parseInt(gameStructure.get("max_players").toString());
                        if (Integer.parseInt(doc.get("players_remaining").toString()) == max_players) {
                            return;
                            // throw new IllegalStateException("No pueden haber más " + max_players + " jugadores en la partida");
                        }
                        PreferencesManager.setGameId(gameId, GameSelectionActivity.this);
                        PreferencesManager.setGameName(doc.getId(), GameSelectionActivity.this);
                        PreferencesManager.setPlayerId(playerId, GameSelectionActivity.this);
                        PreferencesManager.setUsername(playerName, GameSelectionActivity.this);
                        Map<String, Object> updates = new HashMap<>();
                        updates.put("game_id", gameId);
                        updates.put("chips", gameStructure.get("starting_chips"));
                        FirebaseStoreManager.db.collection("players")
                                .document(playerName)
                                .update(updates);

                        Map<String, Object> updatesGame = new HashMap<>();
                        updatesGame.put("players_remaining", Integer.parseInt(doc.get("players_remaining").toString()) + 1);
                        if (Integer.parseInt(doc.get("btn_player_id").toString()) == 0) {
                            updatesGame.put("btn_player_id", playerId);
                        }
                        FirebaseStoreManager.db.collection("game")
                                .document(doc.get("name").toString())
                                .update(updatesGame);

                        Intent intent = new Intent(getBaseContext(), PokerActivity.class);
                        intent.putExtra("game_id", gameId);
                        startActivity(intent);
                    }
                }
            }
        });
    }
}