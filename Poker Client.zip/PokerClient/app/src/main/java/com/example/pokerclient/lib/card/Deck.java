package com.example.pokerclient.lib.card;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Deck {
    private List<Card> cards;

    public Deck() {
        this(true);
    }

    public Deck(boolean shuffle) {
        initDeck();
        if (shuffle) {
            shuffleDeck();
        }
    }

    public Deck(List<Card> cards) {
        this.cards = cards;
    }
    public void initDeck() {
        cards = new LinkedList<Card>();
        cards.addAll(Arrays.asList(Card.values()));
    }

    public void shuffleDeck() {
        Collections.shuffle(cards);
    }

    public Card dealCard() {
        return cards.remove(0);
    }

    public List<Card> exportDeck() {
        return cards;
    }
}
