package com.example.pokerclient.lib.card;

import com.example.pokerclient.R;

public enum Card {

    TWO_OF_CLUBS("2c", R.drawable.two_clubs, 1),
    THREE_OF_CLUBS("3c", R.drawable.three_clubs, 5),
    FOUR_OF_CLUBS("4c", R.drawable.four_clubs, 9),
    FIVE_OF_CLUBS("5c", R.drawable.five_clubs, 13),
    SIX_OF_CLUBS("6c", R.drawable.six_clubs, 17),
    SEVEN_OF_CLUBS("7c", R.drawable.seven_clubs, 21),
    EIGHT_OF_CLUBS("8c", R.drawable.eight_clubs, 25),
    NINE_OF_CLUBS("9c", R.drawable.nine_clubs, 29),
    TEN_OF_CLUBS("Tc", R.drawable.ten_clubs, 33),
    JACK_OF_CLUBS("Jc", R.drawable.jack_clubs, 37),
    QUEEN_OF_CLUBS("Qc", R.drawable.queen_clubs, 41),
    KING_OF_CLUBS("Kc", R.drawable.king_clubs, 45),
    ACE_OF_CLUBS("Ac", R.drawable.ace_clubs, 49),

    TWO_OF_DIAMONDS("2d", R.drawable.two_diamonds, 2),
    THREE_OF_DIAMONDS("3d", R.drawable.three_diamonds, 6),
    FOUR_OF_DIAMONDS("4d", R.drawable.four_diamonds, 10),
    FIVE_OF_DIAMONDS("5d", R.drawable.five_diamonds, 14),
    SIX_OF_DIAMONDS("6d", R.drawable.six_diamonds, 18),
    SEVEN_OF_DIAMONDS("7d", R.drawable.seven_diamonds, 22),
    EIGHT_OF_DIAMONDS("8d", R.drawable.eight_diamonds, 26),
    NINE_OF_DIAMONDS("9d", R.drawable.nine_diamonds, 30),
    TEN_OF_DIAMONDS("Td", R.drawable.ten_diamonds, 34),
    JACK_OF_DIAMONDS("Jd", R.drawable.jack_diamonds, 38),
    QUEEN_OF_DIAMONDS("Qd", R.drawable.queen_diamonds, 42),
    KING_OF_DIAMONDS("Kd", R.drawable.king_diamonds, 46),
    ACE_OF_DIAMONDS("Ad", R.drawable.ace_diamonds, 50),

    TWO_OF_HEARTS("2h", R.drawable.two_hearts, 3),
    THREE_OF_HEARTS("3h", R.drawable.three_hearts, 7),
    FOUR_OF_HEARTS("4h", R.drawable.four_hearts, 11),
    FIVE_OF_HEARTS("5h", R.drawable.five_hearts, 15),
    SIX_OF_HEARTS("6h", R.drawable.six_hearts, 19),
    SEVEN_OF_HEARTS("7h", R.drawable.seven_hearts, 23),
    EIGHT_OF_HEARTS("8h", R.drawable.eight_hearts, 27),
    NINE_OF_HEARTS("9h", R.drawable.nine_hearts, 31),
    TEN_OF_HEARTS("Th", R.drawable.ten_hearts, 35),
    JACK_OF_HEARTS("Jh", R.drawable.jack_hearts, 39),
    QUEEN_OF_HEARTS("Qh", R.drawable.queen_hearts, 43),
    KING_OF_HEARTS("Kh", R.drawable.king_hearts, 47),
    ACE_OF_HEARTS("Ah", R.drawable.ace_hearts, 51),

    TWO_OF_SPADES("2s", R.drawable.two_spades, 4),
    THREE_OF_SPADES("3s", R.drawable.three_spades, 8),
    FOUR_OF_SPADES("4s", R.drawable.four_spades, 12),
    FIVE_OF_SPADES("5s", R.drawable.five_spades, 16),
    SIX_OF_SPADES("6s", R.drawable.six_spades, 20),
    SEVEN_OF_SPADES("7s", R.drawable.seven_spades, 24),
    EIGHT_OF_SPADES("8s", R.drawable.eight_spades, 28),
    NINE_OF_SPADES("9s", R.drawable.nine_spades, 32),
    TEN_OF_SPADES("Ts", R.drawable.ten_spades, 36),
    JACK_OF_SPADES("Js", R.drawable.jack_spades, 40),
    QUEEN_OF_SPADES("Qs", R.drawable.queen_spades, 44),
    KING_OF_SPADES("Ks", R.drawable.king_spades, 48),
    ACE_OF_SPADES("As", R.drawable.ace_spades, 52);


    private String identifier;
    private int drawable;
    private int evaluation;

    private Card(String identifier, int drawable, int evaluation) {
        this.identifier = identifier;
        this.drawable = drawable;
        this.evaluation = evaluation;
    }

    public static Card getCardByIdentifier(String identifier) {
        for (Card c : Card.values()) {
            if (c.getIdentifier().equals(identifier)) {
                return c;
            }
        }
        return null;
    }

    public static Card getCard(String card) {
        for (Card c : Card.values()) {
            if (c.toString().equals(card)) {
                return c;
            }
        }
        return null;
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public int getDrawable() {
        return this.drawable;
    }

    public int getEvaluation() {
        return evaluation;
    }
}
