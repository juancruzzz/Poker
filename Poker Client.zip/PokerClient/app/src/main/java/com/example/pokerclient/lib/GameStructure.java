package com.example.pokerclient.lib;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameStructure {
    private BlindLevel currentBlindLevel;
    private int blindLength;
    private Date currentBlindEndTime;
    private Date puaseStartTime;
    private List<BlindLevel> blindLevels;
    private int startingChips;
    private String description;
    private String name;
    private int maxPlayers;

    public GameStructure(String name) {
        this.name = name;
    }

    public GameStructure(String name, String description, int maxPlayers, int startingChips, int blindLength) {
        this.name = name;
        this.description = description;
        this.maxPlayers = maxPlayers;
        this.startingChips = startingChips;
        this.blindLength = blindLength;
        this.blindLevels = Arrays.asList(parseBlindLevels(BlindLevel.BLIND_10_20,
                BlindLevel.BLIND_15_30,
                BlindLevel.BLIND_25_50,
                BlindLevel.BLIND_50_100,
                BlindLevel.BLIND_75_150,
                BlindLevel.BLIND_100_200,
                BlindLevel.BLIND_200_400,
                BlindLevel.BLIND_300_600,
                BlindLevel.BLIND_500_1000,
                BlindLevel.BLIND_1000_2000,
                BlindLevel.BLIND_2000_4000));
        Collections.sort(blindLevels);

        this.currentBlindLevel = this.blindLevels.get(0);
        this.currentBlindEndTime = null;
        this.puaseStartTime = null;
    }

    public GameStructure(String name, String description, int maxPlayers, BlindLevel currentBlindLevel, int blindLength, Date currentBlindEndTime, Date puaseStartTime, List<BlindLevel> blindLevels, int startingChips) {
        this.name = name;
        this.description = description;
        this.maxPlayers = maxPlayers;
        this.currentBlindLevel = currentBlindLevel;
        this.blindLength = blindLength;
        this.currentBlindEndTime = currentBlindEndTime;
        this.puaseStartTime = puaseStartTime;
        this.blindLevels = blindLevels;
        this.startingChips = startingChips;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public void setMaxPlayers(int max_players) {
        this.maxPlayers = max_players;
    }

    public BlindLevel getCurrentBlindLevel() {
        return currentBlindLevel;
    }

    public void setCurrentBlindLevel(BlindLevel currentBlindLevel) {
        this.currentBlindLevel = currentBlindLevel;
    }

    public int getBlindLength() {
        return blindLength;
    }

    public void setBlindLength(int blindLength) {
        this.blindLength = blindLength;
    }

    public Date getCurrentBlindEndTime() {
        return currentBlindEndTime;
    }

    public void setCurrentBlindEndTime(Date currentBlindEndTime) {
        this.currentBlindEndTime = currentBlindEndTime;
    }

    public int getStartingChips() {
        return startingChips;
    }

    public void setStartingChips(int startingChips) {
        this.startingChips = startingChips;
    }

    public Date getPuaseStartTime() {
        return puaseStartTime;
    }

    public void setPuaseStartTime(Date puaseStartTime) {
        this.puaseStartTime = puaseStartTime;
    }

    public List<BlindLevel> getBlindLevels() {
        Collections.sort(blindLevels);
        return blindLevels;
    }

    public void setBlindLevels(List<BlindLevel> blindLevels) {
        this.blindLevels = blindLevels;
    }

    public BlindLevel[] parseBlindLevels(BlindLevel... levels) {
        return levels;
    }

    public Map<String, ?> toJSON() {
        Map<String, Object> game_structure = new HashMap<>();
        game_structure.put("description", this.getDescription());
        game_structure.put("max_players", this.getMaxPlayers());
        game_structure.put("current_blind_level", this.getCurrentBlindLevel());
        game_structure.put("blind_levels", this.getBlindLevels());
        game_structure.put("blind_length", this.getBlindLength());
        game_structure.put("starting_chips", this.getStartingChips());
        game_structure.put("current_blind_end_time", this.getCurrentBlindEndTime());
        game_structure.put("puase_start_time", this.getPuaseStartTime());
        return game_structure;
    }
}
