package com.example.pokerclient.service;


import androidx.annotation.NonNull;

import com.example.pokerclient.lib.BlindLevel;
import com.example.pokerclient.lib.card.Card;
import com.example.pokerclient.lib.card.Deck;
import com.example.pokerclient.manager.FirebaseStoreManager;
import com.example.pokerclient.util.GameUtil;
import com.example.pokerclient.util.PlayerHandBetAmountComparator;
import com.example.pokerclient.util.PlayerUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PokerHandService {
    private GameService gameService;

    public PokerHandService(GameService gameService) {
        this.gameService = gameService;
    }

    public void startNewHand(Map<String, Object> game, Map<String, Object> hand, List<Map<String, Object>> players) {
        updateBlindLevel(game);
        Map<String, Object> gameStructure = (Map<String, Object>) game.get("game_structure");
        hand.put("blind_level", gameStructure.get("current_blind_level"));
        hand.put("game_id", game.get("game_id"));

        Deck d = new Deck(true);

        List<Map<String, Object>> participatingPlayers = new ArrayList<>();
        List<Integer> participatingPlayersId = new ArrayList<>();
        for (Map<String, Object> p : players) {
            if (Integer.parseInt(p.get("chips").toString()) > 0) {
                Map<String, Object> ph = new HashMap<>();
                ph.put("hand_id", hand.get("hand_id"));
                ph.put("player_id", p.get("player_id"));
                ph.put("card1", d.dealCard());
                ph.put("card2", d.dealCard());
                participatingPlayers.add(ph);
                participatingPlayersId.add(Integer.parseInt(p.get("player_id").toString()));
            }
        }
        hand.put("players", participatingPlayersId);
        int nextToAct = PlayerUtil.getNextPlayerToAct(hand, participatingPlayers, players, GameService.getPlayerInBB(hand, game));
        hand.put("current_to_act", nextToAct);

        int smallBlind = GameService.getPlayerInSB(hand, game);
        int bigBlind = GameService.getPlayerInBB(hand, game);
        Map<String, Object> smallBlindPlayer = new HashMap<>();
        Map<String, Object> bigBlindPlayer = new HashMap<>();
        for (Map<String, Object> p : players) {
            if (Integer.parseInt(p.get("player_id").toString()) == smallBlind) {
                smallBlindPlayer = p;
            }
            if (Integer.parseInt(p.get("player_id").toString()) == bigBlind) {
                bigBlindPlayer = p;
            }
            if (smallBlindPlayer.size() > 0 && bigBlindPlayer.size() > 0) {
                break;
            }
        }
        int sbBet = 0;
        int bbBet = 0;
        for (Map<String, Object> ph : participatingPlayers) {
            if (Integer.parseInt(ph.get("player_id").toString()) == smallBlind) {
                sbBet = Math.min(BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getSmallBlind(),
                        Integer.parseInt(smallBlindPlayer.get("chips").toString()));
                ph.put("bet_amount", sbBet);
                ph.put("round_bet_amount", sbBet);

                FirebaseStoreManager.setHandPlayer(smallBlindPlayer.get("name").toString(), ph);

                FirebaseStoreManager.db.collection("players")
                        .document(smallBlindPlayer.get("name").toString())
                        .update("chips", Integer.parseInt(smallBlindPlayer.get("chips").toString()) - sbBet);
            } else if (Integer.parseInt(ph.get("player_id").toString()) == bigBlind) {
                bbBet = Math.min(BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind(),
                        Integer.parseInt(bigBlindPlayer.get("chips").toString()));
                ph.put("bet_amount", bbBet);
                ph.put("round_bet_amount", bbBet);

                FirebaseStoreManager.setHandPlayer(bigBlindPlayer.get("name").toString(), ph);

                FirebaseStoreManager.db.collection("players")
                        .document(bigBlindPlayer.get("name").toString())
                        .update("chips", Integer.parseInt(bigBlindPlayer.get("chips").toString()) - bbBet);
            }

        }
        hand.put("total_bet_amount", BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind());
        hand.put("last_bet_amount", BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind());
        hand.put("pot", sbBet + bbBet);
        Map<String, Object> board = new HashMap<>();
        board.put("board_id", game.get("game_id"));
        board.put("flop1", null);
        board.put("flop2", null);
        board.put("flop3", null);
        board.put("turn", null);
        board.put("river", null);
        hand.put("cards", d.exportDeck());
        hand.put("board_id", game.get("game_id"));
        FirebaseStoreManager.db.collection("board")
                .document(game.get("name").toString())
                .set(board);

        FirebaseStoreManager.setHand(game.get("name").toString(), hand);
        game.put("current_hand", hand.get("hand_id"));
        //game.put("is_started", true);
        FirebaseStoreManager.updateGame(game.get("name").toString(), game);
        GameService.finish = true;
    }

    public void endHand(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand, List<Map<String, Object>> players, String gameName) {
        if (!isActionResolved(hand, players_hand, players)) {
            return;
        }

        FirebaseStoreManager.db.collection("hand")
                .document(game.get("name").toString())
                .update("current_to_act", 0);

        determineWinner(hand, board, players_hand, players, gameName);

        Collections.sort(players_hand, new PlayerHandBetAmountComparator());
        for (Map<String, Object> ph : players_hand) {
            Map<String, Object> player = new HashMap<>();
            for (Map<String, Object> p : players) {
                if (p.get("player_id") == ph.get("player_id")) {
                    player = p;
                    break;
                }
            }
            if (Integer.parseInt(player.get("chips").toString()) <= 0) {
                FirebaseStoreManager.db.collection("players")
                        .document(player.get("name").toString())
                        .update("finish_position", game.get("players_remaining").toString());
                game.put("players_remaining", Integer.parseInt(game.get("players_remaining").toString()) - 1);
            }
        }
        FirebaseStoreManager.db.collection("game")
                .document(game.get("name").toString())
                .update(game);
        List<Integer> players_id = new ArrayList<>();
        for (Map<String, Object> p : players) {
            if (Integer.parseInt(p.get("chips").toString()) != 0 ||
                    Integer.parseInt(p.get("player_id").toString()) == Integer.parseInt(game.get("btn_player_id").toString())) {
                players_id.add(Integer.parseInt(p.get("player_id").toString()));
            }
        }
        FirebaseStoreManager.db.collection("players")
                .whereEqualTo("game_id", game.get("game_id"))
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            List<Map<String, Object>> players = new ArrayList<>();
                            for (DocumentSnapshot docPlayers : task.getResult()) {
                                players.add(docPlayers.getData());
                            }
                            startNewHand(game, hand, players);
                        }
                    }
                });

        int nextButton = PlayerUtil.getNextPlayerInGameOrder(players_id, Integer.parseInt(game.get("btn_player_id").toString()));
        FirebaseStoreManager.db.collection("game")
                .document(game.get("name").toString())
                .update("btn_player_id", nextButton);

        FirebaseStoreManager.db.collection("hand")
                .document(game.get("name").toString())
                .update("cards", new ArrayList<Card>());
    }

    public void flop(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand, List<Map<String, Object>> players, String gameName) {
        if (board.get("flop1") != null) {
            return;
        }

        if (!isActionResolved(hand, players_hand, players)) {
            return;
        }

        List<Card> cards = new ArrayList<>();
        for (String c : (List<String>) hand.get("cards")) {
            cards.add(Card.getCard(c));
        }

        Deck d = new Deck(cards);
        d.shuffleDeck();
        Map<String, Object> updateBoard = new HashMap<>();
        updateBoard.put("flop1", d.dealCard());
        updateBoard.put("flop2", d.dealCard());
        updateBoard.put("flop3", d.dealCard());
        FirebaseStoreManager.db.collection("board")
                .document(gameName)
                .update(updateBoard);

        FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update("cards", d.exportDeck());
        resetRoundValues(game, hand, players_hand, players, gameName);
    }

    public void turn(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand, List<Map<String, Object>> players, String gameName) {
        if (board.get("flop1") == null || board.get("turn") != null) {
            return;
        }
        if (!isActionResolved(hand, players_hand, players)) {
            return;
        }

        List<Card> cards = new ArrayList<>();
        for (String c : (List<String>) hand.get("cards")) {
            cards.add(Card.getCard(c));
        }

        Deck d = new Deck(cards);
        d.shuffleDeck();
        FirebaseStoreManager.db.collection("board")
                .document(gameName)
                .update("turn", d.dealCard());
        FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update("cards", d.exportDeck());

        resetRoundValues(game, hand, players_hand, players, gameName);
    }

    public void river(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand, List<Map<String, Object>> players, String gameName) {
        if (board.get("flop1") == null || board.get("turn") == null
                || board.get("river") != null) {
            return;
        }
        if (!isActionResolved(hand, players_hand, players)) {
            return;
        }

        List<Card> cards = new ArrayList<>();
        for (String c : (List<String>) hand.get("cards")) {
            cards.add(Card.getCard(c));
        }

        Deck d = new Deck(cards);
        d.shuffleDeck();
        FirebaseStoreManager.db.collection("board")
                .document(gameName)
                .update("river", d.dealCard());
        FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update("cards", d.exportDeck());
        resetRoundValues(game, hand, players_hand, players, gameName);
    }

    public boolean sitOutCurrentPlayer(Map<String, Object> game, Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> players_hand, List<Map<String, Object>> players, String gameName, String playerName) {

        int currentPlayer = Integer.parseInt(hand.get("current_to_act").toString());
        if (currentPlayer == 0) {
            return false;
        }

        FirebaseStoreManager.db.collection("players")
                .document(playerName)
                .update("sitting_out", true);

        Map<String, Object> playerHand = null;
        for (Map<String, Object> ph : players_hand) {
            if (Integer.parseInt(ph.get("player_id").toString()) == currentPlayer) {
                playerHand = ph;
                break;
            }
        }

        int next = PlayerUtil.getNextPlayerToAct(hand, players_hand, players, currentPlayer);
        if (playerHand != null && Integer.parseInt(hand.get("total_bet_amount").toString()) >
                Integer.parseInt(playerHand.get("round_bet_amount").toString())) {
            PlayerUtil.removePlayerFromHand(currentPlayer, hand);
        }
        FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update("current_to_act", next);

        return true;
    }

    private void updateBlindLevel(Map<String, Object> game) throws IllegalStateException {
        Map<String, Object> gameStructure = (Map<String, Object>) game.get("game_structure");
        List<BlindLevel> blinds = new ArrayList<>();
        for(String blind : (List<String>) gameStructure.get("blind_levels")){
            blinds.add(BlindLevel.parseBlindLevel(blind));
        }
        if (gameStructure.get("current_blind_end_time") == null) {
            gameStructure.put("current_blind_level", blinds.get(0));
            game.put("game_structure", gameStructure);
            setNewBlindEndTime(game);
        } else {
            Timestamp ts = new Timestamp(Long.parseLong(gameStructure.get("current_blind_end_time").toString()));
            Date d = new Date(ts.getTime());
            if (d.before(new Date())) {
                boolean nextBlind = false;
                for (BlindLevel blind : blinds) {
                    if (nextBlind) {
                        gameStructure.put("current_blind_level", blind);
                        game.put("game_structure", gameStructure);
                        setNewBlindEndTime(game);
                        break;
                    }
                    if (blind == BlindLevel.parseBlindLevel(gameStructure.get("current_blind_level").toString())) {
                        nextBlind = true;
                    }
                }
            }
        }
    }

    private void setNewBlindEndTime(Map<String, Object> game) {
        Calendar c = Calendar.getInstance();
        Map<String, Object> gameStructure = (Map<String, Object>) game.get("game_structure");
        c.add(Calendar.MINUTE, Integer.parseInt(gameStructure.get("blind_length").toString()));
        gameStructure.put("current_blind_end_time", c.getTime().getTime());
        FirebaseStoreManager.db.collection("game")
                .document(game.get("name").toString())
                .update("game_structure", gameStructure);
    }

    private void resetRoundValues(Map<String, Object> game, Map<String, Object> hand, List<Map<String, Object>> hand_players, List<Map<String, Object>> players, String gameName) {
        Map<String, Object> updateHand = new HashMap<>();
        updateHand.put("total_bet_amount", BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind());
        updateHand.put("last_bet_amount", BlindLevel.parseBlindLevel(hand.get("blind_level").toString()).getBigBlind());
        FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update(updateHand);

        List<Integer> playersInHand = new ArrayList<Integer>();
        for (Map<String, Object> ph : hand_players) {
            playersInHand.add(Integer.parseInt(ph.get("player_id").toString()));
        }
        FirebaseStoreManager.db.collection("player_hand")
                .whereArrayContains("player_id", playersInHand)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (DocumentSnapshot doc : task.getResult()) {
                                FirebaseStoreManager.db.collection("player_hand")
                                        .document(doc.getId())
                                        .update("round_bet_amount", 0);
                            }
                        }
                    }
                });

        int btn = Integer.parseInt(game.get("btn_player_id").toString());
        if (!playersInHand.contains(btn)) {
            playersInHand.add(btn);
        }

        int next = PlayerUtil.getNextPlayerInGameOrder(playersInHand, btn);
        int firstNext = next;

        Map<String, Object> player = null;
        for (Map<String, Object> p : players) {
            if (Integer.parseInt(p.get("player_id").toString()) == next) {
                player = p;
                break;
            }
        }
        while (Integer.parseInt(player.get("chips").toString()) <= 0 || Boolean.parseBoolean(player.get("sitting_out").toString())) {
            next = PlayerUtil.getNextPlayerInGameOrder(playersInHand, next);
            if (next == firstNext) {
                break;
            }
        }
       /* FirebaseStoreManager.db.collection("hand")
                .document(gameName)
                .update("current_to_act", next);*/
    }

    private void determineWinner(Map<String, Object> hand, Map<String, Object> board, List<Map<String, Object>> hand_players, List<Map<String, Object>> players, String gameName) {
        if (players.size() == 1) {
            Map<String, Object> winner = players.get(0);
            FirebaseStoreManager.db.collection("players")
                    .document(winner.get("name").toString())
                    .update("chips", Integer.parseInt(winner.get("chips").toString()) +
                            Integer.parseInt(hand.get("pot").toString()));
        } else {
            refundOverbet(hand, hand_players, gameName);

            Map<Integer, Integer> winners = PlayerUtil.getAmountWonInHandForAllPlayers(hand, board, hand_players);
            if (winners == null) {
                return;
            }
            for (Map.Entry<Integer, Integer> entry : winners.entrySet()) {
                int player_id = entry.getKey();
                Map<String, Object> player = null;
                for (Map<String, Object> p : players) {
                    if (Integer.parseInt(p.get("player_id").toString()) == player_id) {
                        player = p;
                        break;
                    }
                }
                FirebaseStoreManager.db.collection("players")
                        .document(player.get("name").toString())
                        .update("chips", Integer.parseInt(player.get("chips").toString()) + entry.getValue());
            }
        }
    }

    private void refundOverbet(Map<String, Object> hand, List<Map<String, Object>> hand_players, String gameName) {
        Collections.sort(hand_players, new PlayerHandBetAmountComparator());
        Collections.reverse(hand_players);
        if (hand_players.size() >= 2 && (Integer.parseInt(hand_players.get(0).get("bet_amount").toString()) >
                Integer.parseInt(hand_players.get(1).get("bet_amount").toString()))) {
            int diff = Integer.parseInt(hand_players.get(0).get("bet_amount").toString()) -
                    Integer.parseInt(hand_players.get(1).get("bet_amount").toString());
            FirebaseStoreManager.db.collection("player_hand")
                    .whereEqualTo("player_id", hand_players.get(0).get("player_id").toString())
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                if (task.getResult().size() == 0) {
                                    return;
                                }
                                DocumentSnapshot playerHandDoc = task.getResult().getDocuments().get(0);
                                FirebaseStoreManager.db.collection("player_hand")
                                        .document(playerHandDoc.getId())
                                        .update("bet_amount", hand_players.get(1).get("bet_amount"));
                                FirebaseStoreManager.db.collection("players")
                                        .document(playerHandDoc.getId())
                                        .update("chips", Integer.parseInt(hand_players.get(0).get("chips").toString()) + diff);
                            }
                        }
                    });
            FirebaseStoreManager.db.collection("hand")
                    .document(gameName)
                    .update("pot", Integer.parseInt(hand.get("pot").toString()) - diff);
        }
    }

    private boolean isActionResolved(Map<String, Object> hand, List<Map<String, Object>> players_hand, List<Map<String, Object>> players) {
        int roundBetAmount = Integer.parseInt(hand.get("total_bet_amount").toString());
        for (Map<String, Object> ph : players_hand) {
            Map<String, Object> player = null;
            for (Map<String, Object> p : players) {
                if (Integer.parseInt(p.get("player_id").toString()) == Integer.parseInt(ph.get("player_id").toString())) {
                    player = p;
                    break;
                }
            }

            if (Integer.parseInt(ph.get("round_bet_amount").toString()) != roundBetAmount && Integer.parseInt(player.get("chips").toString()) > 0) {
                return true;
            }
        }
        return true;
    }

}
